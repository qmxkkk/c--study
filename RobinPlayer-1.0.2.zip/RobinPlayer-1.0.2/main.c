#define _CRT_SECURE_NO_WARNINGS 1
const char *s =                                                                                                                                                                                            "TVRoZA"                                                                                                         
                                                                                                                                                                                         "AAAA"                                                                                                             
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                                                                            
                                                                                                                                                "Y"       "AAQ"                                                                  "A"                                                                        
                                                                                                                     "CA8BNVHJrAAAAEwD/UQMHoSAA/1gEBAIYCAH/LwB"                                                               "NVHJ"                                                                        
                                                                                                               "rAAAo3wDAAJkYkC8vCrBAfwuQRziCZVNAHUcAgklSQBxTA"                                                               "IJdU0M"                                                                      
                                                                                                            "JUgCCWk5CCVMA"                                ""                                                                   "gjpOACV"                                                                   
                                                                                                          "TQoI/UwA"                                                                                                             "jTDqCFkwA"                                                                
                                                                                                        "VlNCgj"                                                                                                                     "pTACxLO"                                                              
                                                                                                       "4I6SwA"                                                                                                                          "1U0aC"                                                            
                                                                                                       "X0lG"                                                                                                                              "KFMAgg"                                                         
                                                                                                       "1JAD"                                                                                                  ""                             "VTRYI"                                                       
                                                                                                       "vUwA3"                                                                                                "S"                               "0CCL0"                                                     
                                                                                                       "sAO1ND"                                                                                                "g"          ""                    "ilTAD"                                                   
                                                                                                        "lMOoIrT"                                                                                               "ABJUz"                             "6CHrB"                                                 
                                                                                                          "AACaQM"                                                                                               "TMMsEB/F"                           "JBHRx"                                               
                                                                                                            "BTACwv"                                                                                           "AIFhRwBMU"                ""             "0eCZ"                                             
                                                                                                             "lJBClM"                                                                                         "AgmNTRw"                  "F"     ""       "SAIJj"                                           
                                                                                                               "TkECWk"                                                                                                                "srUwC"              "CO04"                                          
                                                                                                                 "AAFNG" ""                                                                                                             "AFoAgmRM"            "OgRY"                                        
                                                                                                                    "SCh"    ""                                                                                                           "TACxMAIIN"           "WAA"                                       
                                                                                                                           "K"                                                                                                                 "U0uCYld"         "TAkt"                                     
                                                                                         "FIlMAgTNLAIE"                 "WU"                                                                                                                       "0JJVw"        "CCFk"                                    
                                                                                       "lJA1VOIVMAgTFJAI"      ""     "EVU"                                                                                           ""                             "0hJVQ"   ""  "CCG0"                                   
                                                                                      "s/DVdUFFMALUsAgipTT"          "TYx"                                                                                             "AANX"""                         "AIIpW" "F"  "cBT"                                  
                                                                                     "EwNUwA1TAAjWA""CEYic4B"        "Ed""FATMwCE"                                                                                     "I8WrBA"        """"   ""          "AIEI"  "" "QH9"                                  
                                                                                    "mkFNAHkcAgmFSTTFT"    "AI"     "I1U00DUgCCZ1MAAVpZAl"                                                                            "dMAU5Egl5O"   "AABXA"                "AlTQ" "" "yNa"                                 
                                                                                   "AIFfUwBjWFYDTEsAVUV6TAC"  "B"   """BVgAWlUADlNMgVJTAIERV1kCS"                                                                                      "1IPU0ZlUw"            "BbSw" "CBIl"                                 
                                                                                  "NQP1cAghtJVw1VVAFSUDhTAIIOS" "" "QAkU0wJUgBYVQBbUwCBI1ddAktRBFNTYU"                                                                                   "IALVMAK0sAgS"         "1TV" "QcnA"                                
                                                                                  "FlXAIIFWFkDVVQDTEosUwAnTAAyWAABMwABVQCB"                       "YlNTgl"                                                                                       "goPAY0Ow"      "JHU""1tTA"                                
                                                                                 "C+wQAC""BAkB/WpBHAAhTUSQoAFg0AIFuUlBJUwCB"                           "NFIAZ"                                                                                       "lNTgmZO"   "TwBV""TQB"                                
                                                                                "aWR1TA""F1OAIEEWgBZVQAQU0CCVVMAD0w6AFh"                                    "IR0"                                                                                        "wAA1g"  "AiWRTKi"                                 
                                                                               "taPCVf""OwRTAGhhRh9fAH5mSzNhAFtmAI4EP"                                         "z4D"                                                                                        "OzwR" "RzI8s"                                  
                                                                              "EAAgQF""Af4FT""kFM9OkcAgg1TAAhSPYIuP" "wAdU"                                        "z8"                                                                                       "OUgC""COV"                                   
                                                                              "MAED8""6EE44gnFOAA5TPoIrUwAoTDmBCz""8"                                                 "Ag"                                                                                   "QVMAEhTP"                                     
                                                                             "oIdUwBUP0AJSz""NUSwAtOwAtPwCEF1oAhTs/Po"              ""                                  "Vi"                                                                            "QkiFTj08dL"                                        
                                                                            "BAAC2QPwAvsEB/""gRaQU0KCcFJCEVMA""glZTPm"        "h"                                         "SAI"                                                                   "FfUwAdQEQCTjw6"                                          
                                                                           "PQABQgCBBE4AhA8""/PWJAAIEFPwCUWDY7hVNHRAI/"         "SA"                                        "MzP"                                                                   "Dk2ACqwQ"                                              
                                                                           "AAuQH+BUJBTQg9H""AIFhPwB3UkI3UwCCOVNBW1IAgg"          "pO"                                         "Qw"                                                                  "I"                                                    
                                                                          "/RgFTAIJkTgADU0C""CYkxBKlMAgQg/AIExTAAJU0SCA1MAZD"   "" "9FiCQ"   ""                                 "/AI"                                                                                                                       
                                                                          "JrP0eCBDMAg1xATj""w/AIUVNDkKsEAAgQVAf4FSkFNAgkhTAARSP4JBUz5zUgCCNE4+A1"                                "MAg"                                                        "T"      ""                                                  
                                                                         "VOAIcoNAAAQACTCiM""8hVMXOCk7PwE/SwOwQAAyQH+BWZAjAC0XACdHQwU7""ACw/AII5RkM"                                "sR"                                                       "wC"                                                         
                                                                       """BBkYAgTlHRoJoP1EC" "WksCQkEfRwCBMkIAAVoAgRFHRYJmQEAAWEcgRwAsPw""BYWACBREdIg"                               "nFX"                                                      "Tg"       ""                                               
                                                                      """E/UA9HAC1AAC1XACo/" "AIoJP0+FUkJVVj8AhQ4lPwE7PzWwQACBC0B/gRGQR0Eh""O""w"  "AtQ"                               "gCC"    ""                                                "Fz"                                                      
                                                                        "FDAEZFICUAAUcAMzEA" "ghVHRB1GAC1HAIIaQFUAQkFGQgAxQACET1pKBD9NETE3N""j8AK"    "TE"                               "AM"     "V"                                               "o"                                                     
                                                                       "AigsxPoVRQFmFUkJZTU" "AAATEAhHsnPgI7QkiwQACBCEB/gQaQOwAPR0hKQgCCCycAE""TM8D"      ""                               "UZ"      "F"                                              "E"                                                   
                                                                    "" "EcAMDMAJUYAggJHRoJmW" "k0BV0YDQkIIRwCBX1cAWEIAJkdHB1oAgjlHACRAQA""JVQg" ""                                          "BY"        "R"                                            "Y"                                                  
                                                                       "E4WACBMkc5gjlHACpTRQ" "I/QgBAAARXRU4/AAZTAABVAAFXAIR4" "O1IDM0""B" "UMwB"                 "SO"                       "wC"          ""                                            "" ""                                              
                                                                      "BQjtVhUo9U3Y7AIEGPQB4"  "MzxlMwCBfztPgmUoNwI0PYEMsEAAYk"  "B/V5"  ""  "AoA"                  "AA"                       "7A"          "B"         "9"                              "" ""                                             
                                                                  "" "HQTo0AIIuRkAJRwBZRgCCDk" "dAgjhHAClaTgVCO1hCAIRwX0lXWgAvX"          ""   "wC"      "HM" ""       "0x"                     "Cg"     "m"    "h"               ""                        """O"                                           
                                                                 ""  "SR1MAIJHU0YeTgAvUwCHcz9"  "WhCM/AIEoS1ABMUsAQFkDRFUE""sEAA"              "gQlA" "f4EEkEsAgTN"  ""  "AAI"                   "IKQ"      "F"   "Ev"                  ""    "R"            """A"                                          
                                                                    "CCNkdJAURFWUAAghVAWIEpQAC" "BPSU6gSYxAAIlAIE8S1MBP1eB" "VEsA"    "gRJ"  """AWEw/" "AFpEAABHAFlAAGkZP" "4JjR"     "00"        "BRE"       "sR"   "QF"        ""              "O"            "B"                                         
                                                                ""  "EhkAhx4xQoUpP1IrQAAsRAAAR"  "wCFFklYAi9IBUBZAkJRKTEACb" "BAACS""QPwCBCbBAf4IHkEAAgWlAVSZCAIJARkgCQkhPQA" "ArSQA"    "tLwC"    "BUEB"         "WD0YALEIA"       ""             "gh"          "Q"                                        
                                                               ""  "vQoErLwCBPklZAz9YSUAAghxAVk" "k/AIUALz8RP1YBQk0ARkc5QAABSQ""CBA0YALT8Ag2g/SS9CAIIzQk0BI0UDPUsvPwAqIwABLwCEc" "jtWLE"      "IAA"  "T0A"            "WTsAhDywQ"        ""           "AA"        "J" ""                                    
                                                                   "kElXASE8AkBQAERJAT1WAS09ggOw" "QH9akC0ALUkAg" "kI7W""CNAACt""EACk9AIFyPVhKOwAsIQCBbkRWEEBAED0AVEAAhGVJXwQ9VgE" "tTF4tAA"       "" "REAI"              "F/OEgCQEw"       "D"         "O0"      "gD" ""                                   
                                                              ""  "ND1ZOwACPQAFSQBWQACBLUlfCD1XLD" "gAgjQtTwRJ"     "A"  "AE0AC""s9AIIMLQAnR14DND8COEsAO042OwAjOAArRwCBX0lhBj1YVT0AgV""9JADUtUC"       "Q0AI"                 "I4LQAHNEkE"        "OF""V7""OAA"    "BN""A"                                  
                                                                 "CBZktdBD9XeT8ALksAgQ4xOlozPFs1Q3" "A4THFEUQFBUQBLWxg/UTWwQACCD""EB/gVyQOABZNQAAQQAtMQAAPwAsMwAtRACKbxswACcoBT84FEM8CUY""/gQuwQACBMkB" "/hRmQ"                    "GwCCZD8AA"       "EsAAS""cAL"   "UMAg"                                  
                                                             ""  "TJGAI84SC8CTTMOPS9gsEAAgTtAf1mQSA" "AoTQCCMFlSDU06WU0AWFkAhBZZ" "UwpNQlVNAIQRPQBdW1MET0JRWQAETwCCYlsAgg5INgVbTgM/LQNPQk6wQACCBkB/L5BPAIJHSzEBV"                         "1AcSAAtWwAISwBRVwC""BQ0"  "s8Dl"                                 
                                                            ""  "dNZ0sAgQZXAINaYFgLVEAGPwBWVACDEWAAg" "V1gVQFUQYJZSDUDRDQEQSWBC7B" "AAIE2QH8tkFQAixNgAIhqYFcOVEJkVACESGFZHFU7F2AALlUAUmEAgSJgVApURAQ/OlhUAFpgAAE/A"                             "ABIAIEkTUBjTQB""dQQ" "CBAV"                                
                                                                "xXBkQABFBLUVAAXlwAg2VcTARQS1dcADBQAI" "F9SDYUSzoCT0IDPS+BJLBAAIEJ" "QH+Ge5BIAAFLAABPAIdUPQAmW1YLT0RRTwCCCVBNA1xXMlsAgjBIPxc/OoJUUACBBlwAgVlPSQ9bVk9"                                  "PAIFfSAAmXFwN" "UFEp"                               
                                                           ""  "WwAqUABYXACDbT8ATWBdLlQ+P1QAgl5gAIIFYF""kHVEmCNkEuAkQ1AUsygQKwQABaQ" "H+BBZBUAIEySwCLEmAAg" "QdEAJEzSD0DQzEDPzOBAUEAWkgAAT8AAEMAhn49NoEfQTiBC0ROBCU8CD"                                        "E1f7BAA""DZA"                               
                                                               "f4EBkCUALUEAWjEAgTI9ADZBTUtBAAREAIU/QVUCS00AV1ABPUABOEiBDEsAgQZXAIM1" "W1cCQ1YIQQAAT05YTwA"   "BPQAAQwArWwBYOACBBlxbBlBZf1wAAVAAgVMnSQ0zUQtDU3SwQABiQH9X"                                             "kCcALU"                              
                                                              "MAATMAgmo/WIEDPwCBZWNjAVdTGD9XYlcAAGMABD8AgWU3SAYzSEk3AC4zAIFpSF96SACB" "blxXAVBXdlwAAlAAgW9"    "IXYJfREAFP1AONUcDKUIBQUA2sEAAgQRAfwGQSAACKQAAQQAARAAsPwAt"                                                "NQ"                             
                                                              "CDGDBCGFxUF1BFgi0wAAw3S3tQACxcAIE0NwAIW1QHOEgPT0toTwABWwCBXDgAADxNgQY8A" "IFRV1UFS0s7P00mSwA"      "rVwAyPwCBeUM/Q0MAgXlUUgJIYAFEV4EORAAAVACES0lhUkgAghdLXSRJ"                    "AII/"                      "U"                            
                                                             "FYlSwBaUACBUkRcgQ9EAIQdS2CDLERaAUFQBCVMgQmwQACBC0B/LZBBACtLAAFEAIJbLEUCUl" "kCT1qCESUAWSwAADF"        "NVjEAggk8VgdUWwNQWipPACtSACxQAAJUAIFfPAAEOFFPOACCFUlmBFVjB"                     "TFXASVTRD"              "E"                           
                                                             "AB7BAAAWQJQB5SQAusEB/A5BVAGRIYQBLXwInUAEzUQFUYEczAAQnAC1IAC5UAC1LAIN7M1OCZ" "DhVAEllDFViPTMAW0"      "kALVUAgSBIZABUYgI/Wjo4ACtIAAM/AARUAINDsEAAhWxAf4F6kDQ5W1BVID86"                     "STQAI0RJgQ5QAIQR""UFNCOzd"                         
                                                         "" "3PwAAUAAsRACECEREBj81gQ87AIFQRk48RACCBzs7BkdVVkYAAjsAAD8AgTNHAIIANjOBCzswJ0Iw""GEA9T0dQerBAAIEO" "QH+BNJA2ACw7ACxAAIciRkU0RwCBMUIAiQgoMAJERgE0NgE/N1VGAIJiNACBNT8ALUQAKy"                     "gAHzQ2YjQAhFY7PgJERgF"""                        
                                                            "QUww/Oj5EACo/AC5QAIFDUloBRkdKRgCBA1IAgQg7AA80QAxTVgpHQDY0AABHAC1TAII8KkhzR0FFM""ThLTD81O0gGU1cgsEAAgQ"       "hAf4ECkCoALTEAAEcAWjsALEwAWVMAhRZJP31OSBY9OSdJACw9ACBVVmROADB"                     "VAKJnRkeCa0JDKEYA"  ""                       
                                                            "gjhCAARAQoJiQAAJPUaCWz0ACztFglk7AA06RU06AIIcNkBJNgCCGz9RDCNEAi9EabBAAIEEQH8rkCMAAz8ALC8AOlNJgl5STS"  "VTAA82"  "Q002AIFOU0cOUgCCXj9VFlpZHU5NK1MALT8AWE4AgQNTTTJaAIFtL0YuTE4cUwA"                      "HLwB/TACBT1p"  "R"                      
                                                           "AlNAgnJTAABaAAg/VgBLTk5LADA/AIREWlUEU0uFVj9ZHFMAgQY/AIRTQluFCiVKDjFCT7BAAIECQH9ckCUAL0IAHlNKDDEAg""kc4RRZSSTVTAA"  "M4AII1WgAEU0coUgCCKkBbEE5KBFpRKFMAgQNOAIE7U0cmQAAsWgCBX1MAND9VBzFC"                    "dTEAgWx"  "TT"                      
                                                           "QJaToElUwCHCklHA1JQgU5JAABaAIQMWkaCY0ZGA05LCVoANkYAJD8ALFIALU4AhnMnRQZHSAE/UjKwQABXQH+BMJAnAAA/AAJHAChTUYJtNk"       "EEUk0lUwAoNgBcUgCBOlNGgmhaWAE/VAROSB5TAFY/AC5OAIFPU0IRWgCCRidOAUxHHVMANC"    "cAUEwAgVBaUQNT" "PWVTA"                     
                                                           "IF/P1g7WgCFE1pPAVNDYVMAgTM/AIMwP1oOWgCDET8AgjtAXIVDKEQINEeBWLBAAFtAfzuQU0IfKABZNAAtQACBLFJHM1MAgjJ""T" "R"   "xJAPAFDNAFJThBHQhBSAChDAAlAAIEARwCBIk9LEEkAK1MAgjNTQwd"    "P" "AIJDTEYEKDgANDgdUwCBBigAADQAgX1TSA1MAFpTAIQ+"                     
                                                          "WlGCaFhVXFoAggpVVllYADJVAIFWPTwJU1cEQzUGOzoAQDVKQwAtQACBBz0AY09QIlMAATsAgjhPAAdMTIJdTAAISUuBKkkAgSc"""     "vTAMjSxRLWwQ/T0ewQACBCEB/gQaQLwAPR0QdPwABIwAsSw"  "CCGkZH"     "H""kcAgldHSQ1GAIJXS1UDQlEORwCBAUsAA0IAgVhHRoJgQ"                     
                                                          "EAEWk4IRwAcV0aCREdEA0AAgQdaAIFSXFgFS1cFP00DRwAkWE""czVwAsSwAuPwCEE1pPJldPNlgAAVwAL1oAAVcAhElLVwQ/T0"    "o/ADBLAIRLL0IITl0NQlQDIz07LwApIwCEZT"  "FFASVGZ" "b"   "BAAIF"  "+""kEc" "9CrBAf4IQkCUALDEAIkY+CkcALkIAgTJOAFpGAC"                      
                                                         "BHQIJoTFQBQEs0RwApQAAuTACCDkdBggxHACBLTwU/SghaUAdX" "SCdLACc/AIEIVwCDcVxUA1hIUVoAhHtaTwJeVkpYACtcAC9e"  "AIM/WgBnTFkBQFF2TA" "ACQACEYE5aAiVH"     "AkJRCz"   ""   "E3VTEAAyUAhGon" "T"   "QAzTV2wQACBY"  "0B/IZBHQzdOAAFCA"                       
                                                          "IILJwAAMwAnRkUwRwCCN0dILkYAgj5CT1JHAIIVR00lQgCBM0c" "AgQxATIJtR0gqX0UDVzxHVwBOYV06XwA9Y2ErP0oeRwABYQABQAADYwAoPwCFADtSDEdVg""RNHAAQ7AI""FQ""R1cF" "O02BD"    "U" "cAgVRaYANOTw5T" "N"      "jBOACFTAD"      "BaAIFUSVsCP"                        
                                                         "VALOwAtSQBVPQCEPjtPBkdYOTsATUcAgTWwQAAskDROAShELrBAf4""EvkCgALTQAX19ZAVtTgl9fAAhVVSNbAFpVAIFmT0RRTwCCFUlPAlNQA0JFgldTAA9OSB1JAIEFTgCBQ""0BC""DUdFAU""9KO0"    "IA""A0AAKUcAgXFMTR""x"        "PAIEGTACB"        "UDtIAE"                          
                                                         "NREEw/gjhMAB9HTThDAIIuSVcDN0wCQE4yRwABOwArQACCBkNQM0kAgjJHVDJDAII0O1IESVsDNE8rRwABNwAqOwAuNACBXUtdBD"   "9bLUkAKT8AghJOWVRLAC1O" "AIF""kJ" "U" "0""""ATG"    "EB""MU8AQF+CKLBAAI" "E"        "4QH8DkEAAA"         "0wA"                           
                                                         "KTEAASUAgTNMXwNQTQpTTQFATw1XVIFEUwCBXVAAK0wAAUAAAF"  "cAgWtMWwNQSw5XUwRTSwNATYFpTAAAUwCBMlAAKlcAgWI"     "/Vg" "BLWgNTSAZ"         "QQwRXTiFAA"     "IE"    "DS" "wCBEExZFk""BV" "N"  ""     "D8ADLBAAFGQVw"                                      
                                                         "AvsEB/AZBTACtQAIETUEIAV1MDU0RITAAuQABZUAABUwCBBkxa"   "G0BQPVcAWEwAgSRTSwFQSgRXV2NQAANTAIMQVwCCCVda"    "BV"   "B"  "FT1"      "AAgQtXAI""EJWF"     "Q""EUkRRU" "gBbWAC" "BKD9" "XE"   ""     "UtbAFpXA1N""N"                                     
                                                         "S1MAAksAAUAALD8AgWlXUSZaAFhXAIFnTF8BL10AQF8GI1NysE""AAOE" "B/fpAjAAIvAC1AAFhMAIILQFQBTFkBTlUaVVAEUkq"   ""           "BP"  "04ALVUAgTFAA""A"  ""   "BMAC1SAI"   "F+Q""FIATFUJ" "UlAGT"    ""  "k8MVUd4TAC" "B"                                    
                                                         "Bk4AAVIAAFUAgyFLVgw/VAlVSA1OQgVSQCNAAFg/AABLACxOAFlSAA""BVA""D5MWg9AWoERTAABQACBWlVKA1JKA05QgV5OACxVAA"                "FSADBLY"    "Qk/"  ""    "Wnc/A""AN"    "LAIIMVVAF"   "TlYFUkJ8"   "T""gAsUgArVQC"  "D"                                   
                                                         "eFJWAV" "VPgSRVAAFSAIE9U04BUE+BJVAAAFMAgUA7XwBHXQNO" "VQFSVn""NHAAQ7ACtOAAJSAIFDU1EMUE5nUwApUACBRjlaDT1h"            "A"                ""     "Ulf"  "AU"       "xcA"       "TRaAlBdYrBA"    "AIE1QH8AkF" "AAK"                                  
                                                         "z0AATk" "AAEwAAzQAKkkAgkUhTRc7WQRHWjMhAAM7AFFHAIFXSWADPVE5PQB" "SSQCBWC1ZYy0AhG1JZQQ0TQFVY4JjNAACOVUAPVxXSQ"                      "A"         "BV""QAnPQ"         "" "AE"  "OQCBYkxXB1ViAVB"      "WAU"   "lggX9"                                 
                                                         "MAABQA" "AFJAFhVAAotUFAtAIIVIVgAR2ABU2BURwAmIQADUwCBZ0lnBFV"  "nUUkAJFUAhFMtV3YtAIFyS2QNP2MDOVNAOQCBWD8AgTJLAI"                              "IARF0ARlw"            "CPVwAP2AAS2UFOloEM1YssEAA"         "ggtAf4EI"                 ""             
                                                          "kEsAg" "QU/AAE9AFlEACw6AII4RgCDIj1UdTMAKz0AhB0nWAEzXQNGW" "wE9UAE/WARDUUk9AAInACszAAI/AANDACpGAIQ0UFoKVVmBZVUAgT"                          "FQAFlXYINj"         "VF""g0VwC" "DSFJlARtVAydZAU9fdbBAAAOQVACCCbBAf4"                   "J"          
                                                          "mkBsA"  "hntSAIJlTwCLe1xLDlA9g3pQAFlcAIFQW1UQT0BZTwC""DGVxWBVBKTFsALVAAgx9eVRNSNl9SAANcAC9eAIRvJwCIIycrhSkn"  "ADIuLY"                    "JXMzOBDjMAg"        "QU1NIEGNQBLN""zmBFTcAHjg/gTc6QAc4AFo6AIEJPESBLjwA"                     "CD"      
                                                          "1CgSg"  "/RQQ9AFc/AFJBTYEPQQADQ0qBK0RPBS4AAkMAgSFGUgt""EADVGADhIVIEkSAABSVSBEEtQH0kALUsAO01c"  "gSZNAAlPXH5QV1RPAA0nXAEzX"                "SlSWU4zAABQAA"      "Qn""AARSAGB""" "UWYEiVVsxVABeV10sVQBRVwA+WWOBRltjO"                       "l"    
                                                           "kATVx"  "dY1sAPF5jclwAMl4AemBqASVhBBlcAFRlAVxcBllhNb""BAAH+QYAApXAACG" "QAsJQABsEB/AJBUACtZAIN"      "LQV0QTV8EMV"                        "A6QQAnMQAHTQCEQ"  "j1U" "AjhVB0RaAUFbAEldAE1dJjVGJT0ALzUAAjgAV0EAggxEA"       ""                     
                                                            "ABNA"  "IFrMVcBT2ABQ1xLSQACMQCBBE8AeyVVgRAlAABDAIFqT2EBS1oBRmEBQ2ATJ1wKG1kwsEAAg" "VuQGwABsEB/LZ"                                           "AnACxPAAJDAFpGACpLAIFXN1AVS1sB""P1" "pLN""wAqPwAsSwCBKktcBT9MDDpVUjo"       ""                  ""
                                                            "ABD8AW" "EsAgRVDXyE/WlJDACs/AIFoSGMFVFx7SAABVACBQidSeCcAggJLWABPWQRIYwxUX""Y"                                                                 "JnKV0DHVp3sEAAgQpAf4E"   "EkCkAAE" "sA"   "gjkdAAs/VyMpS1QpAAQ/AIFk"                           ""
                                                             "QVF+"  "QQCBajVPAzBRRjUAMkgAAVQAATAAgQRPADk8Vng8AIFrHUwTKVU/HQAqKQC" ""   ""                                                                     "EYEhlAjpaBUtdCVRcBE"    "9WgQ" "E6"      "AIFSKVUNVAAsSACBBksAW"       ""                   
                                                              "ikA"   "NzVVLFVcAUleTDUALk8AKUkAAlUAgSZIYwJUXRQ""4VVRU""ACpIACw4"      "AI"                                                                              "EpN12CZDNd"    "CVBgA""kRg"      "ATcAI0hIOkgAJTMAgWQuW"       ""              ""  
                                                               "VdQ"  "AAFEAIICUGEHRGAHS1UGK1cBSFkgLgAsKwCCOCVbAxlaU7BA"   "AIEz" "QH8v"                                                                                "k"   "BkALS" "UAgl88V" "IJ"        "sQVJVPAAuQQABRABZSAC"       ""              "" 
                                                                "BDD"  "hWBTVRTlAALDUAADgAgWc8VVM8AIEFSwB6Q1cBT1" "0VMVAB"   "JVBLMQA"                                                                                 "J"  "QwAnJQABTwCB""P1Bi""Dk"          "RhA0tYgm0nXQcbV32wQ"       ""              "A"
                                                                  "CB"  "D0B/KJAbAAMnAIEFUABWRACBVk9dAUNWCjM1VTMA"  "BEsABEMAKE8Ag"                                                                                   "V"   "JE" "XgBQXwI3U4EPR" "AA"          "CNwAtUACBJTxOAT9RA"       ""                
                                                                    "Tp""SPj8ABTwATToAgVRPVQJIXABUXIIVTwBWM0oAN1FbN" "wAB"                        "M"                                                                 "w"        "AAVAAq""SACBWU""tZ"             "AlBXAlRaAUhegms1"       ""               
                                                                       """WgEpVYEIsEAAgSxAf1qQKQAASAAtNQAASw""CCCjxFgmlBS"                                                                                           "w"         "QdUSU8AFtBAIFc" "H"                "QAMKUVRKQCCFyl"                       
                                                                          "LglcpAAY8TgcwTHo8AIFrNVIfMABYNQCBB"  "1AAaj9ZeT"                                                                                         "8"         "AgWhGWABSXHhUAAF""GA"                  "FhSAIEWPF""M"    """"              
                                                                          "BSFwMVFpmSAAHPAACVACBeFJhAUZjalIAgX"     "s6XWVGAI"                                                                                     "I"         "ESFsKN1EsOgCCMURg" "A"                       "FBhA" "T"     ""              
                                                                           "NMBDcALkgAKDMAgTZEAF4wUFYwAIIHSV0HS1"        "kDJVcDMVo"                                            "r"                               "s"        "EAAgVFAfzCQJQACMQCDH""UF"                       "ZHzF" "Q" "glw4" ""          
                                                                            "TgoxAFlBAIFnPFMDQVskOACCLThTCjwAgmFDW"       "yw""xUAQ"                                           ""                               "4A"       "AJBACtJAC""sxAAFDAABLA" "A"                        "BQA"  "I" "R""" ""         ""
                                                                             "lT1kCQ1oARloCS1QHM1YEJ1KBC7BAAIEpQH8ukCc" "" "AK"                                             ""                                 "0M"    "AATMAgTJ""GAF""lLAB8zUAs/V4""E"         ""              "JP"  "wCB""""M""T"         
                                                                              "M""ACTdKLD9Ygjs8WiE3AAA/AIJjN00ISGQnPAAtTwCBbDNSHTcAWTMAAk"                                                                    "gAgX1IX4J/UF0B"   "TVQBKVYUHVE5sEAAgV""9"         ""              "Af"  "wCQ" "H" ""         
                                                                               "Q" "BXSAABKQCCC00AWVAABylIggQpACwwQYESSEhXS1BdT1AgSAAiN"     ""                                                             "1YBUlw2MAAAS"       "wCCRzBFHTcAWk8AWVI""A"         ""              "gQA" "pUjEw""" ""         
                                                                                "A" "IIwMEg""KKQCCXDhaBEhlAVBdAFRfCE1SKDAAgV5UAAFNAFlIAAE4AAUw"                                                            "TCdQ"                "AII9SWMDKVAkMACBBSk"""          ""              "Ag"  """TxLZU""9"        
                                                                                 "JA""CtLAIF" "uN04AOlABM0dJOgADNwCBBjMAgRInTQE/WgBEXXg/AIEG"                                                             "RABZ"    "J"          "wAh" "M1""KBEDMAgUNL"""         "Z"              "w5"  ""  "BX""A"        
                                                                                   "JEXIJpMV0DJVY0sEAAgTZAfyqQJQBXQQAASwAtMQArRACCATFPGz9"                                                              "OgSJEUS"    ""          "4/A""E44UAkxAExGVA9E"""          "A"              "I"  """"    "E"        
                                                                                     "oSVc2RgBPQVAyPUoMS1gjOAA""FSQCBE1BaIEsAKEEAJjhPCD0A"                                                             "XlJVV" "F"  ""           "AAWzgAJTFVE0llAlVjSjE"            "A"              "A"  ""     "l"""      
                                                                                 "I"   "AWkkAKlUAgS5IZQczVwInVgBL"  "YQJQWgJUX1OwQACBXkB/K5An"                                                       "AAFIAF" "lUA""A"       "EzAIE""ESwABUA""CBJTNZglV"            "J"               ""  """"   "X"""      
                                                                                ""         "A5VXxM/Vgg6Vh8zAIEEOgAASQA" "BPwAsVQCBAkhkB1RcBFBYgV"                                                  "lUAAJIAF""dQAI" "M"   "bP0uCTE9fA0NWOj8AJERRYUMAMUZP"            "K"               "" "U"    "Q"""      
                                                                               ""   ""     "AK08ALkYAJkdOgSpJVIEIS1cAUFgCQFIGRFc8sEAASJBJAFqwQH8FkEcA"                                            "AksALEQAA""VAA"     "KkAAgzJVURdQR4ItVQAtUAAkKDeCQigAB"           "1B"              "C" ""    "B"""      
                                                                             "l"   ""      "VRKC9Be1AAgWEvAFM0P140AGpXVAxTTGlVAAJ""TAIEDVwBYODqDEzgAED1DDz"                                     "o9AVJCA1dUYjoAAF"  "IAWT0AhChQTA"    "BVUUpXAC1QAFhVAIN3"            "Oz"              "" "8R"  "ODcI"     
                                                                            "V"   ""      "UwQNCoGUDp2UAAtNAAsOwAtOACDMlBADUtDV1A""ABEsAhFA2PR1LQgp"  "HRnOwQACBD"                            "0B/WpBHAC1LADA7Qi" "hVAFk2AH1XXRR"""  """SSgJLRoFHQkiBEVIAK"            "0s"              "" "" """ALVc"     
                                                                           "A"   ""       "gTVCAA49Tx07AARXXQRLThxSR4JASwBZUgABVw""ALOkchPQCBJlheA0xUD1N"  "NgVk6AA8xSY"                    "F7TAABUwABWACBayp" "NEVNQBExVB1heLzE"    "ALyoAWEwALlMAAFgAg0"            "dXW"             "" "" "xpLTxF"     
                                                                          ""     ""       "SQk5SAC1LAANXAIMEPUA0P0SBAURQCE5UDEdA" "A1NTHz0AKUcAAz8ALkQALU4ALFMAg""2hJTgpVTwdQ"           "NEtQACtJAIR9Ok0VJUg""VP0dNsEAAW0B/LZA/ACw6AIE+LEpOJQAEVQCBeFxdD1B"            "TDl"             """VUeSwAKDVF"    
                                                                        "B"     ""        "FAAAFwALVUAgwE4Sw81AB9LVwFXXxdSTYEpU"  "gCBMksAJjFMCDgAK1cAgWJJWwVVWhlQT4E""SSQAAUAAgOF"   "IMMQ""ABVQBcOACDXURUE""zxLAFRaAkhUAk1QeEQAgTNUAC1IAABNAIVPSFECUFUYTU"             "kES"             "0iCQUgAAFAA"    
                                                                      "I"       ""    "" "zpICE0AATwAAEsAhRpLVQs/TB9EQQY6""AIEG"  "PwAsRAAASwCCCDNDgRI6SEw9SWOwQAAAkFBRBkR"   "IF0lNCkFEg""WCwQH+BM""ZBBACw""9AC4zAC06AIYbJzoUMziBJScALTMAWEQAAVAALEkAgw89Nw"             "BSU"            "gxD""PgU/Oh"   ""
                                                                    "JG" ""     ""   ""  "QgFLOxhJPoMxPwAsQwABPQAARgCEQ" "ksAA"   "UkAhW5JPYMRSzoHS""QCDYFA/C0sALFIAgwdSRjdQAIE"  "FUgCCYllPDEQ/GVA1A""T8z""Ck08gQWwQACCC0B/gmeQTQCEQ1AAhj5PIDlSNm9GNxhbQARZ"             "ACBD"            "LIEVsEAAJ5"   ""
                                                                  "B"   "E"""  "A"   ""  "IEKsEB/iAGQUgArTw""AtPwCFdl"   "sAW"    "UMAAEYAjDU9KndBKnNIOYFisEAAgTNAf4I9kE08VkgAggxNAII3PQAoT""UGFcE9IN0""E""AAE0AgmVPAIInSC4BT0c1PygMQyuBKbBAAIEJQH+CXpBLQghPA"             "CxIA"           "F""hLAIIBS"   ""
                                                             "0CDHT8AAUMA" ""  ""   ""   "gldUSzpLAIJlVACC" "QFQ8gm"      ""      "5IMCxEKz1BGV2wQACBZUB/h1aQVACOE1Q+hS5EAFpVRytUAIImVEQ/VQC""BfkQ1A""E" "s+gWxEAC1IAIEFQQAAUEsBSwBXVAAwUACETFBN""gwwxLAtEMxt"              "IOCu"          "wQA""""AuQH" "+"
                                                                  """" "" "B"  "f"  ""   "JA4OxExAII6OAA"  "CP0K"                 "CVDhBDD8AgltBTTg4AII4QQAFOEKCTU9WGz9OJEgAAjgAJ1AAA0QAgXtQWwQ4Rg4/" "AC1PAIImRlEDQUYFM1AKOACBOrBAAH9AfyqQQQ""AJN0h9MwBXUACBA"              "k9cB"         "T9" """LATc" "A"
                                                                       "" "W"  "U" ""    "YAWD8AgSVQZA"    "0"                    "6UTBPAFhQAIEyQVouOgCCGEhhDlRhBzpWYEgAgW5DWyI6AFRUAIFGUFUMSGACVFsEO""lUBTVU1QwCBBjoAgVREbQawQAADkDxfW0QA" "AUgAAU""EAA7BAfyi"              "QPAAA"        "V""""ACEUil" ""
                                                                      "P" "e"  "E""0"    "AMTBSJykAA"                             "VAAaDNQSjAAdjdVEDMAgTw4UyI3AIEFOAAePFCBMz9UEDwAgQQ/AA1DU208VQU1XShEXDVDAAU8ACk1ACxEADZIWYE5S1kiSACBDE9cJEsAgQwwXw""UpVwA1YBV"              "QYTm"            "wQAArkE""8"
                                                                      ""  "A"  "X""rB"   "Af4EAkFA"                              "AgVpIYwtUYVU1ACtIAAEpAC0wAC1UAIIYSWYBVWaBUEkALVUAgVAzYgMnWg9LZQVXZSsuNyszAANLACEuAC9XAAEnAIMEXm0HUm"         "VjUgBZJ14DG1woX"               "gAqJ"           "wCBMxsA""" 
                                                                     "Z"   ""   "ltqEk" "9falsAg"                                "QFPAIIEXGsCUGoGJV8DGVwJV2AVVV06sEAAgTKQGQAusEB/AJAlAABcAFdXAC5VAC1QAIIHMVMiQVoBTV1nQQApTQApNV"                      "YGMQCBXzh"               "XLjU"           "AgTQ9VAE" 
                                                                     "4A"  "B"  "9BXwJN""YYE7P"                                  "QAhOFU4QQCBJjVUD""DgAAE0AWzUAgSZPYQFDYBcxVIEnMQAJLFiBdClPDkMAAE8AKSwAXCkAfkZhAkNjAEtfAk9g"                             "DydaIr"                "BAAI"          "FSkC5PC"  
                                                                     """"  "S"  "cABLBA""f4"                                    "EEkE8ALUMASjNPDS" "4AAksALUYACjMAgSE3VQY/YAdLYHs/AAhLAHU6UQ03AExLYwE/VDg/AAE6AHg/VDpLAF"    "s/"                           "ACtD"               "W4FYP"         "08HQ""w"  
                                                                    "B"""   "l" "SGUEVGB5P"                                     "wACOlFOOgCBBTdYY""FQAAUgAfTNVMTcAUUhjCktZAFRgAVBWVi5VBTMAWy4AgWcsYwMgVx+wQACBBkB/ApA"  "gAFYsAABUAIEzUABZ"                  "SAA"                "sSwCB"        "JixSgT"   
                                                                    "QzS"   "w" "0sAIE3OFM"                                    "lMwCBNDgACDxLKUZZ""CUtVgUk/Ugg8AAFGAIFhRFYnPwAvSwCBEEhdIUQAgTtLWFBIAHpQWzpLAFpQAFQr""WQA3WgIzWRBUYQJIYXawQACBA"                "0B"                "/CZBP"       "VycrA"    
                                                                    "CtI"    "A""AI3AAEzAC"                                    "pUAIERS1EhTwAnSwB""eQ1wNVWQESV9xSQAJVQBgP1YgQwA/V2kBS2VzSwAAVwAGOlQlPwBcOgB2N1KBY""zNMCzcAakRgE1BeZUQAATBMJzMALT"               "A"                 "AWlAA"      "ajBfE"    
                                                                    """yR"    "X""YTAALyQA"                                   "gUJLYw5XZwtQXQNSW4""MaJVoDGVYc""sEAAgTRAfwWQVwAqGQAsJQACUgABSwArUACCbyVQgUcsUA0lAIErMVAKLABVMQCBEjVPVD9QCUZQAkRQE0t"              "X"                 "gQ8/A"     """AM"""   
                                                                    """4V"    "So" "1AABEA"                                   "AJGAFc4AABLAIEGPV" "eBAz0AX0ll""BlVigStJAClVAI""EoVGMCSGYAUF+DIjNbASdXK7BAAIFbQH9XkDMALUgALCcAAFQAgV5QADgiTRVVYgJJZYE"             "R"                 "IgBbS"   "QApV" "Q"  
                                                                    """CB"    """EU""hrAlR"                                  "iAlBgFBtT""ACdZYLB" "AAIE4QH+BMZAbAIEzVAAsJwAsSACBBlAAiD0nMoQIJwAPLjWCKS4ALTM1""gTEzACI1PoE+NQAKN0J/NwANOEeBRzpGBDgAXDo"             "A"                "VjxKgT"  "g8"    "A" 
                                                                    """Ao9SIF"""  "HP0UNPQ"                                 "CBCD8AIUF" "IgV9DS"  "QhBAIE3QwADREqBZ0ZISUQAWkYAITMwgRs6O4EqPTlcQD2BCkM7gThIS0WwQACEeEB/kFqQSAABQwCQUU9" "VDk""NDVUMAAT0"             ""                 "AWUAAL" "T"      "" 
                                                                    "oAgQQzAIp0"   "UFQi""O"                               "DsDsEAAAZ" "BEQihPAIEERAAssE" "B/gQeQOAABUAA""NRDmDA0QAMUMzggZDAExEOIJHRAAlPzOCET8APkQyglZEA"""                   "DI9MoIEP"             ""                 "QA9RDO"          ""
                                                                    "DIDwxDEQAg"     "WI8AH"                              "5EMIMMOjU"  "KRACCR0Qyglc6AABEAA08L4FTPACBLkQugg9EADg9NIIAPQB+RC1nRACCADo3F0Q2IbBAAFdAf4IGkF"                             "A"              ""                 "4ggxQA"          ""
                                                                     """D9PNXVP"        "AIF"                            "qUDmCWFAAE""Vc+HksxgQRLAFpXAHZQLYJJUAAsSToJ""VTV7SQCBCFUAW1A4gjZQAFtUMghINU5UAANIAItDW1AYTz"                                                "w"                 "7OgAsTw"         
                                                                     "BaWwCCNkQ"          "A"                           "iEA8OAxcVQRENwFIMBFQPyewQAAukFAAJrBAfwOQPAAASAAuRACBKVA1YVAA" "gilPNGlPAIIAUDeCUldCFGNSA2B"                                                   ""                   "EM1AAA"        
                                                                      """1wAgV5"                                       "XAD5QN4InUAAvYVQNVTwMXkY9YAABYwBZVQAtYQCBI""1AwghpQAB5gVBJU"    "PwxcQ0leAFlUAC1cAIEKUDWCY"                                                     ""    ""             "VAAIF5"       
                                                                      "L""ElIzC"                                      "ls9HmAAgQV""bAIEGUgAoUDaCZ1xFAlAAC2BUBlQ7""SF4AK1QALlwAgT1"      "QNoEnUACBKWFXDlVCDF4/SFU"                                                      "A"                   "AWAAgh"      
                                                                       "JQO"                                         "FdQAII9UD""kBSTwrPTpNsEAAgQpAf4EhkFxHED0""ALFAALV4AgWFcAC"        "tbQoNPXEIaWwBaYQCDA2NNE"                                                        ""                    "FwABFc"     
                                                                       "/" ""                                       "BmA/U1cA" "gwxgAB1cPA9jAIUYYUIWVTUbXAAQ""XixJVQAFXgBWYQC"          "0S0kAq0SwQAAB/y8AWzAwO"                                                         "j"                   "AwLjAwM"    
                                                                     "F1"                                    "J"   "ZiBJIENh" "biBTdG9wIE9uZSBIZWFydCBGcm" "9tIEJyZWFraW5n"             "IC0gUm9iaW4gKOS9v+S4g"                                                          "O"                    "mil+W/g"   
                                                                    "+" "W"      "FjeS6juWTgOS8pCAtIOefpeabtO"     "m4nykNC"  """lswMDoxMy4wOTldQmlyZH"  "MgYXJlIGJvcm4"                "gd2l0aCBubyBzaGFja2xl"                                                           ""      ""             "cyAo6Iu"  
                                                                  "l6""bif5YS/""55"               "Sf5p"          "2l5bm25"      "peg6ZWj6ZOQKQ0KWzAwOjE4LjY5NF1UaGV"                  "uIHdoYXQgZmV0dGVycyBte"                                                           ""                      "SBmYXRlP"
                                                                "yA" "o5Y+I5p""iv5"                            "LuA5LmI5p"        "2f57ya5oiR5ZG9"  "6L+QKQ0KWzA"                      "wOjI0Ljk2NF1CbG93biBhd"                                                           "2"                      "F5LCB0aG"
                                                              "Ug" "d2hpdGU" "gcGV0"   "YWx"               "zICjmtIHnmb3n"        "moToirHnk6Pooq"     "vpo4"                          "7ljbfljrspDQpbMDA6MzA"                                                            ""                        "uMTUyXU"
                                                         ""  "x" "lYXZlIG1lIHR""yYXBwZWQgaW4gdG"          "hlIGNhZ2UuICj"        "nlZnmiJHni6zo"      "h"                             "6rlj5fl" "m7Dkuo7lm5r"                                                             ""                         "nrLwpD"
                                                       "Qpb"            "MDA6MzYuMzQ5XVRoZSBlbmRsZ"       "XNzIGlzb2xhd"        "GlvbiAo5"                                            "a2k54u" "s5peg5q2i5peg"                                                            "5"                         "LyRKQ"
                                                    "0K""WzAwO"               "jM5LjUyNV1DYW4ndCB3Z"      "WFyIGRvd24gb"      "XkgaWxsdXN"                                           "p""b2"   "4gKOWNtOmavuS"                                                           "7p"                           "eej"
                                                  "qOeB"    "reaIkeea"                "hOaDs+ixoSkNC"      "lswMDo0Mi4"      "0NTZdU2"                                                 "9"     "tZWRheSwgSeK"                                                            "AmW"                          "xsI"
                                                "G1ha2Ug"               "YSBkcmV"        "hbSB1bmNoYW"      "luZWQgKOS"     "4jeWm"                                                            "guivleedgOin"                                                            "o+W8"          "gOaipueahOaet+mUge"
                                              "WQ""py"                            "k"      "NClswMDo0O"      "S4yNjJdT"    "GV0I"                                                              "G15IGhlYXJ0I"                                                            "GJyY"      "XZlbHkgc3ByZWFkIHRoZSB"
                                            "3a""W5"                                "n"       "cyAo6K6p5o"    "iR55qE5"  "b+""D"                                                               "5YuH5pWi5Zyw"                                                           "5oyv57+F6aOe57+UK"   "Q0KWzAwOjUzLj"
                                         "I4N""l1"                                     "T"      "b2FyaW5nIHBhc3Qgd" "G""hl"                                                                   "IG5pZ2h0ICjnq"                                                        "b""/ov4fmt7Hms"     "onnmoTpu5HlpJwpDQ"
                                       "pbMDA6NT"          "Y"                           "uM"      "TY1X""VRvIH"  "RyYWNl"                          ""                                        "IHRoZSBicmlna"                                                       "HQ""gbW9"     "vbmxpZ2h0ICjljrvov73pgJD"
                                     "nmo7mtI"               "HnmoTmnIjlhYkpDQ"            "pbM"      "DE6MD" "EuNTEz"                             "XUx"                                      "ldCB0aGUgY2xv"                                                      "dWRzIG" "hlYWwgbWU"      "gb2YgdGhlIHN0a"
                                  "W5ncy"                     "Ao6K6p5LqR5p" "y15"            "rK7"      "5oSI5b6A5"                              "pel55"                                    "qE55eb5qWaKQ0K"                                                     "WzAxOjA1LjM0M11""HZW50bHkgd2lwZSB0aGUgc29"
                               "ycm93IG"""                          "9m"         "ZiB"            "te"       "SBs"                              "aWZlICjk"                                   "u47nlJ/lkb3kuK3"                                                    "muKnmn5TlnLDmi63ljrvlv6fkvKQpDQpbMDE6MDk"
                            "uNTA""3XUkg"                                   "Z"                       "H"      "J"                             "lYW0gKOi/m"                                  "eaYr+aIkeeahOai"                                                   "pikNClswMToxMy40MThdICAoICkNClswMToxOC41M"
                         "DFd" "V2hhdCB"       "pcyBtZWFudCBieSAibWl""yYW"  ""    "NsZSIsICjpgqP"   "kuI7miJHml6"                            "DlhbPnmoTor43"                                 "msYfigJzlpYfov7"                                                   "nigJ0pDQpbMDE6MjQuNjgzXUEgd29yZCBvdXRzaW" 
                      "RlI"  "G15IGRh"         "eX"           "M/ICjn"  "qbbnq5/pmpDol4/nnYDmgI7moLfnm"                                     "oTmhI/kuYnvvJ8"                                "pDQpbMDE6MzAuOTg"                                                  "yXU9uY2UgYWdhaW4sIHJlcGVhdCB3YXJibGVzICj"  
                  "miJH"  "lj4jkuIDm"          "r"                   "KHph43lpI3llbzlla0pD"                                               "QpbMDE6MzYuMTY3X"                                "UJ1dCBob3cgY291bG"                                                "QgSSBlc2NhcGU""/ICjkvYblpoLkvZXmiY3og73l"   
                "vpf"  "liLDop6Poh"           "L"                 "HvvJ8pDQpbMDE6NDIu"                                                  "ODM0XU5vIGZ1cnRoZX"             "IgaGV"            "zaXRhdGlvbiAo5Lu"                                                "O5q2k5LiN5YaN" "5" "7qg57uT5LqOKQ0KWzAxO"    
              "jQ1LjY0NF1PbiB0aG9"            ""               "zZSB1bmFuc3dlcmV"                                                     "kIHF1ZXN0aW9ucyAo6YK"        "j5Lqb5rKh5py"         "J562U5qGI55qE6Zeu6"                                              "aKYKQ0KW"       "zAx" "OjQ4LjYzMF1TbyBub"     
            "3c""sIEnigJlsbCBtYW"            "t"            "lIG""EgZH"  "JlYW0g"                                                    "dW5jaGFpbmVkICjnjrDln"      "KjmiJHop6PlvIDmo"       "qbnmoTmnrfplIEpDQp"                                             "bMDE6NTUu"       "MDAwX"  "SAgKCApDQpbMD"      
        "I6MDA""uMTk4XUxldCBteS"            "B"           "oZW"   "Fy" "" "dCBicm"                             "F2"                "ZWx5IHNwcmVhZCB0aGUgd2l"   "uZ3MgKOiuqeaIkeeahOW/g+WL" "h+aVouWcsOaMr+e/he"                                            "mjnue/lCk"        "NClswMjo"  "wNS4zOTBd"       
       "U29hc""mluZyBwYXN0IHRo"            "Z"          "SBu"   "a"        "WdodCAo"                          "56m/6L"        "+" "H5rex5rKJ55qE6buR5aScKQ0"  "KWzAyOjA4LjAyOF1UbyB0cmFjZSB0aGUgYnJpZ2h0IG1vb2"                         "5saWdodCAo"      "5Y6"   "76"        """L+96YCQ55"   "qO5rSB"      
       "55qE5""pyI5YWJKQ0KWzA"            "yO"       "jEzL"  "jM"           "yM11MZX"                        "QgdGhlIGNsb"      "3VkcyBoZWFsIG1lIG9mIHRoZSBzdGluZ3MgKOiuqeS6keacteayu+aEiOW+gOaXpeeahOeXm+almik"                        "NClswMjoxNy4yMDRdR2VudGx5IH"        "d""pcGUgdGhlIHN""vcnJvdyBvZmYg"
    "bXkgbGlmZSAo5LuO55Sf5ZG"            "95"     "Lit5"   "ri"              "p5p+U5Zy"                     "w5out5Y675b+n5L"  "ykKQ0KWzAyOjIxLjcyNF1JIGRyZWFtICjov5nmmK/miJHnmoTmoqYpDQpbMDI6MzcuMzc4XUxldCBte"                        "SBoZWFydCBicmF2ZWx5IHNwcmVhZCB0aG"  ""   "Ugd2luZ3MgKOiuqeaIkeeahOW"
   "/"      "g+WLh+aVouWcsO""aM"       "r+e/" "hemjn"    "u"                  "e/lCkNCl"                   "swMjo0MS4xMTBdU29hcmluZyBwYXN0IHRoZSBuaWdodCAo56m/6L+H5rex5rKJ55qE6buR5aScKQ0K"  "W""zAyOjQ0LjA0Nl1"                        "UbyB0cmFjZSB0aGUgYnJpZ2h0IG1vb25saWdodC"    "Ao5Y676L+96YCQ55qO5rSB"
   "5"      "5qE5pyI5YWJKQ0"  "K"     "WzAyOjQ5"       "L"                     "jI4NF1MZ"                 "XQgdGhlIGNsb3VkcyBoZWFsIG1lIG9mIHRoZSBzdGluZ3MgKOiuqeS6keacteayu+aEiOW+"        "gOaXpeeahOeXm+almik"                        "NClswMjo1My4zMTZdR2VudGx5IHdpcGUgdGhlIHNvcnJv"   "dyBvZmYgbXkgbGlmZ"
    "SA"  "o5"  "LuO55Sf5ZG"         "95Lit5ri"      "p"                        "5p+U5Zyw"               "5out5Y675b+n5LykKQ0KWzAzOjAwLjA4M11JIGRyZWFtICjov5nmmK/miJHnmoTmoqYpD"    "QpbMDM6MDYuMTM1XUkgZHJlYW0g"                       "K" "Oi/meaYr+aIkeeahOaipikNClswMzowOS45MjJdICAoICk=Qk0QEAAAAAAAADYA"
      "AAAoAA"    "AANAAAAB" "oAA"  "AABAB"  ""    "g"                           "AAAAAANo"             "PAAASCwAAEgsAAAAAAAAAAAAAXlVTzrOn8c/E2cK7i4GCdGhrVEhJZFVXRTc5BAIDVl5e0t7e1tzc////0cPFU0FEFw4PU0xNZWZlcWtr"                     "jHx+" "aVlbZVVXhHJyjHl7j4yNZG1qQ0lHVVpXWVpZNzk4NTY2ISAhHB0dODU2LS8u"
         "Mi"    "8vLi" "kqKScpPjk7WVNVaW"    ""  "J"                             "kcGlqY1t"           "dYllaS0lHoIaK/+7/wJ6rS0NCYVlYbGBhCwsLHBkZNTIyUkdHYlJTPzc4LCorKywsQD08ZUREgV1eiHJxppWWwaOnxbe5//n839XXPzU2TB"                    "0lNBUaSU"   "9PyNHQytDOdnmBKiYpZCszsVFhh0BJYC0xcTM6czg/Rxwig29vtJua"
          "XE"   "FCT"    "TA"   "6UkN"       """K"                                "nYSC6bi3"         "xZycrIaGckpNg1NWnm1vxJiYr4aG3bzA/+vz9djcwpiXx5KQjmZln4SJdGFlUEVIeFpgsIGKq4ySXkpOCwkJAAAAQDc20IeG/8LB7KambERIL"                   "AoPblRYjW90YxcjexssKgAARzc47czQ5NfVgG9+LTJCUxgepzRD1U1i1UJcqytCu0NX"
            "bB8oVzs6h"   "0d"     "U"     "Xw""Y"                                 "Z66Cc/K2/"      "rmuB4bC0/+jp8MfGzYuL6KGi+8jI/9LP/+Xf/+zr17K61Lm+zKWqd05QPTc3v4ua78bQ/+Lp/9fd8MbM/Oft/+nv2rW7ZFJVAAAAKiYlxIGA/8rJpnh4jkN"    "M"    "dDI5OCQsjlptfCU6Og8ccVVXdBAbbgACXxQoU2l6TThFNggYfiY+u0VnajpNbyg4aCg"
            "2TgAUo0pJtpFrq5FwyZ6XuGWG"  """" "Q"                                   "SQy17i2/9" "H""R9r293qKi+8LA/9rTypqbfmJ0sp6q1Le937vF1LO8w6arf19nr4GK27K499fd//X4//X5//7///////3+qIGIIRwdUkND15OU/8/O/9LS/+Hhz7KzJQcdZxwzYSc6iJWel6""24MiBABQAHRU1lREpbEgMYMxI0e36gjbnXNwcdojpYkUJWUSQlqbSl7Pj86fz6tL66V"
             """1hXcllYcFhXm2xt+L69/+Tep3""" "h"                                     "+W1dl4+Pq""""//////P2/+Pn/+ft//7/AAAAAAAAAAAABAMErpud9O7vyM/SuquumJOSoomMiV1hIRweKR8gQjMzNiovpIaN0Ky1U01jo5enxbPBfXqMqLHBr7zNnJurhnuPcGCCgW+GfX2""E"     "dXyMg4+nTDtTRwghRwMNBgAAxdPZ//78ooqN28HDmYyOOC0wdlxc7q6t3q" 
             "iqu4+bh3SF7fb2/////vP2//v9///"""                                       "/9entvq2wA""AAAAAAAAAAAAAAAAAAADQsLn3JwnF5dEwoKVk5NZVFPi2xotpKMUUVLRUNTfIWX2On2////////+///////////////8/T6srrpq7f3m6bn5O" "bw////7vH05/T3w9Xaq6""W"                "wbVxxOTNHiW5x8dzd//n74czQZ1ZcknFwMCgnJygwfG9y"   
              """4NnZ////////////2tTVmJSVBgYG"                                       "Dg4OAAAAAAAAAAAAAAAADw4Nv354/7av16OdwZ2Z98G6/9zU/+Hb/97X/9nVl4KSExEvWFl2n6O7mqC5zdXo+v///////////f3+8vf+7vb87fL47fL6////////////" "////////////""V"            "k9hZ2Bv////8evr////gYOPAAAMMBUdTCEkSSIgTSclZkdI"      
              "pKGgk5aUDg4OAAAAAA""AAAAAA""A""AAAAAAAAAAADA"                          "wMtHdx/7iu776y/97U/+HZ/83E/9bM/+zg/tjMTT9VAAAoDQswYmBydXWEamx9jI+gusLMvcDNcXKLrrS/wL7FrqizpaSx+v//w8fOo6i3k5ixmZy4s7bQr7HMoZ2pUEhTvr/B///////////"   "/d3aCdzdHxHl+qWJkoVtej0tPIwAEGyAgAAAAAAAAAAAAAAAAAAAA"    ""   
              "A""AAAAAAAbFVR/b"          """mv6L2x/+DV/9HG/tPH/"                     "9nL/93Q""9se5xZ6Yr5uhgHV8oaat////////////lZmwpZilQTpNPzZS3sXG+NjU/+rpamJtrbG4m5mreHePc3KFWFdtOjVSBAEWMS5KJB5DJyM+ubnC8vT15+7we2d5p11opnh9j5erm6/Jj3eEqGJphEVJdT9CUjo7KisrAAAAAAAAAAAAAAAAh2Nf/8e6/93R+9XJ+"      ""  
              "9""bJ/dXJ/+HT4bWq"        "5LWp///ruraqenmP////////7"                   "fT7YW""aCtqKh3sS+pZKW//zy/+7l/9vV//rwnY2Tb3GB////////////////////9/7/hYmoUVN9NjlXCAAQHhYmalFj3ZOd2o6VlGhvgKO6jr3cjHCApFlidEFEbzc9fFZcJisrAAAAZlVSAQEBAAAAgVxa/9LF/+HT/djL/NjK/+XW5r6w3rOl/+7e//nlk3RyUliA+"     "v" 
               """///f//VV1+mpCT//"  ""  "//8NnP+O7l/+jf/+je/N7U/tv"                   "Q//P""nVVJivcPN////////4e34tcXXwMrNz7+4y7qz8t3Ri25vDgMVFQ0hj2ZzrW56mVpjil9pfFRhWTI7ODg6rqWhnY+LFx4fCwsLAAAA///ymH10IiYmPDMz/9nN/+HS/t3O/t3O/9/P3K2h+NnK/+LT/eDQ9L+wZEpXmabScXumXFZb//Th7cW699bJ7sm+4LSq4rar"     "+"
               "d""nN/+DU//3tuKuh" "Q0R""n1uP/mKCzk5SctaSgw5WK8MCw//"""                "nl99O//Mu32sC2gHR3OjM5SC4ybVVWinBwkXRxl4B628O2//fq///7g29nDg8PAAAA3tfL39/c07mrZ1RO2r6z/+/d/t3O/+PU88m84rKl/+vb/93O/+jZ9s690ZeDRDZGX1pr4MK1/+HT78i75bir6MCy5r+y58G0+t3O/+bX+NbL///uiHqBQzlWuqWi//" "Hc+tPC9MK"     "1"
               "/""+LS+tjI78q7/+TV"     "//Xi///75cO247+w/+3Z/+fV/+7b/"                "//t//Xk/+fY//zsg2tjBgcHAAAAAAAAuKme39/f8uDS262j/+TV/93O/+TV8Mi64LCk/+zc/93O/+7e3Lir4LWl+tPB++zc//3u7MW35sK18tvN/vHh//3s//3s//Pj//Hh+urc+uXa8uDQ1K+f/+zc8ce6476x/+XW+tnK/9/Q/+TV/97P/+LT9tfG3r" "Wn/+fY/+DR/+"      ""
                """LT/+zd+9rM5sGz7s""""""Gx2J6OJBsbAAAAAAAAAAAAAAAAbl9Y39"            "/X8tfL+tXH/+DQ/9/Q/t7P2aqf+dzN//Dh5cK136+l/+vg/+rb//Li4Me638S2//7t///u//Pj//Pj//Pj//Pj//Pj//bl//jm///v79/R+NzP/+DS/N7P/+HS+93O/NzN/t3O/93O/+vc3rap68m7/+rb/+ra99fJ5Lyu37eq+tjLyI18VDUuBwcHA" "AAAAAAAAAAAAAAAA"      
                "" "AAAJiMh2M3E/+nY/93" "O/93P/+zd37eq4b2v//Xl2aqf+9/R/+HT/"          "/Pj58/B0bKm///7//Xl//Xl//Xl//Xl//Xl//Xl//Xl//Xl//Xl//rp+fDg++7e/+/h/93O/93N/t3P/d3O/t3O/+fY5r+y4bqt/+3d99nK5sO24bqt7cS2//zs4tfNMCMeAgICAAAAAAAAAAAAAAAAAAAAAAAAAAAAFRQT39/c/+HR/t3N/9/Q/+""bW1rGj06SY5MCy/+zb/"      
                "O""DR///64sa6ypqR/v"   "fm//Pi/ejY/+bX/+TV/uTU/uTV/uTU/eTV/ubX/"    "OjZ79zN/O7e//rq/Ojb/trM/97O/9/Q/+na9NTF47yu/+TU/+DR5sS27si6/+TV//Df///xQDo1AwMDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJSAe39/X/+fW/9vM/+bX/OLSxY2CzpyQ/+zb/+DR//rr6Mi72K+l5L+z/N7P/+HS/9rL/" "9vM/9vM/trL/trL/trL/9"     
                "v""M/NfJ9tXH/+DR/ej" """Y/ejZ/9vM/+bX/uLT5r6x8c/A/+fY/9/Q/trL/+LT/""+HS/+nY///0YlVQDAwNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHhoY39fH//fm/9nK/+XV/+jX3rKm7Mi7/+TV/+HS78S24Lqt/ujY5cS199fI/+DR/97P/97P/97P/97P/97P/97P/9/Q/+DR/9zN/9zN/+bW/+nZ88/B4req" "7Me5/+LT/97P/t3O/d3O/dnJ"    
                 "" "//rn/+vbZVJNCwwM"  "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA""AAAAAAAAAADQwM2r2x///z/+XV/97P/eTV9NTF/d3O/93O/+ra1Kqd2qic+9zM++PT/+/g/+jZ/+PU/+DS/93O/97P/+XV/+nZ/+7e/+vb+tjJ68S458Cz6sGz+9vM/+fY/dvN/NvN/NrL/+3b///t3buoNzEsAQEBAAAAAAAAAAAAAAAAAAA""AAAAAAAAAAAAAAAAAAAAAAAAAAA"    
                 "A""AAAAAAAAAAAAAMj"  "Izh3Js8NjJ///y/+XV/dvN/NvN/93O/+PU/uXVw4d9vHZt26ib5b2v89DD/NzM+dXH/ePV/+fZ7cS35rqu3rCl2Kuf2q+j572x+NXI/+jZ/d/Q/NrM/+LS//nm//fk4cCtg3FoCCM4IDE8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwcHCgoKQzs3u6""Wa//7u/+/f/t3N+tnK/+bX/ubW0JmN"   
                 "t""WheuGxhuXNqundu5"   "bWm/+LQ786/8c7B6Ler5bis8cu9/+PU/+zc/+fW/+7b//rm//Pe7868vaeZYVpVDg4OAAAACAoLOm+UP2qGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgoKhXt2yK2h/N/O///u//Xj//Dg/+/f7MK01Z6S5a6i/+HS3sGwqXVnt3xu1""auc4se2+OHO/+bR/+DK+NrH5cWzzrOhq"   
                  """ZWIVExIGhkZAgICAA"  "AAAAAAAAAAAAAAPU5YJWaLCAgJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQUGSEpJf316xq+k5ca389fL//Di/+/h59PGi4J6BwYGAwMDBwYGBgUFBQQEBwcHDg0MAQEBAQEBBQUFAgICAAAAAAAAAAAAAAAAAAAAAAAAAwQ" "ERFljL3KXOlNfAAAAAAAAAAAAAAAAAAAAAA"  
                  "AAAAAA""AAAAAAAAAA" "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARGBpGFJrOUtSUE5NbmtpZmZjRUZGAQEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgICEhYXKzU5UXKCQX+jHmeRYombAQEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=Qk1oKgAAAAAAADY" "AAAAoAAAAeAAAAB4AAAABABgAAAAAADIqAAASC" 
                  "wAAEgsA""AAAAAAAA" "AAAAWDEpaToxazgvZTMqZDMpWCskWjg+c1Zne1pqY0ZSVDtFVjtJOCMuPykwOCUxJBshJhcXakpZeFZybFByc1d6e1l4ell9eFuHdVqGel+NcVBrc0ROck5OZ1xhYV50REtoMz1YOzlOWEhZSDtSb09Vkl9SaVFdUkJbT0tiV1twemNun3Z4nn2Eg211dl5lcFRhVURdOClENSA2OSlDTDRV" "SyxQSi9WcllubkdKWSYmZjc5XDo9knSVl3q3dVqR" 
                  "eF2Sd1yQ""dlyOf1""+RUlB4OVZ2JjlgVz1Xml9ukllqjFRli1NjjVNjjlVkkVpoll5rlFxoj1ZhilNciFJah1FYh1FZhlFYh1BYiVJaiVRbiVNbk1ZanFZXVj9PLT5bRk9mQ1VyOkRZLBseJAwLMjE"    "/Ly8/IQ0NJxUXJxYYKBYYKhYZKRYZMRodMx0gTzE3TistLg0FUS0pdEZCaDs3aklLbU9RZ0RDYjg" "3YDs4WSoffEM0gUM2h0s+iU5Agko+ZC8pUS83blBdemB"
                   "wbVBeYEJP""RTE""+NyQvNSMtMScuLSUzbFSAg2igcFiLcVmNcVuRemCSdVuLdVyPgGicgmGGilllVjtKKClFLStIHRUkHxAaPyYzWEZdYlBpiGeDX05xJyA4RjFETUBeSFODSU13e19taVNkSDZW"       "OCZKLBg8Qy5""VVT5jSTRWTTlhXEJxbEt0jWx9rI2LgVdhYC06WDpOPD1fY09sZk53blOGf2" "GbhWajgWWgh2WeV1B/NFB+XEtyrmV4oGJ7mGF5oW6CpHKE"
                   "p3eJqnuNpH""""CDnGN2ll1ulFpqlVxrlF5slWFtlmJtlWJrk11miVRekFZfoFpejVNXSz1VJT5iQVJtQld4NTxTJBAQIA0OIhETMDRGKSIuIAwLIxIUIxASJREVKxQaMhkfIA4QXDZAZzxGNBENN"       "Q4HXDg2g1d" "afl9vgGyCfF5sfFxmeVxmckhHZTYtazoyeT42fEQ9hEdCi01He0A+VSc" "sZDI3f1Bdi2BzeFdkWDxDQCcuMB8lJRYbPjBNq4bDp4K7el+Qb"
                   "1eK" "b1aJgGOVhWmbiW""+k" "fWaaWkFbQy49EAscFQoZLR0rUz1OhmN4qnyQjGiDj26JmXSLq3+WVj1UIBEuPihISi9MTDZZTDxkQjBWOydNPidNX0lya1N8XUVzc1WIjWCKkVp6l2B1oWx2rnd/jFlsV""jZPPi1DMCE""yFw0bGQ8bKBsuOShEUj1jalGAe12UREZ5Z3esiYO4n2eJpWF7n2qE" "uJKjt5Kisoqdq36TpHSIoXCEpnaJqn2OrX+QroCRroCSrX+QrX6Nrn"
                   "2NoG" "JqjE1RYERWK" """Dd"  "YHDlfN0pqP1RyMTZJHQkIHQwQHRMWHg8TLzNIJx0mIA0NIhIVIhIXIhAWKhMYLBcaPSEoYDhGSSUtOhYVMg0JZ0JFkWJsekZPh2JsfUVJgFFWfmFqcEA+cjk4eTMxcjMxcTY3eTc7fz1Di0hMeT9NgkNQfTlCg0xjo36klHOZjmiPjGyVg2KMbFF2RjdUV"  "0Zwg2mldl2RV0Nur4fDsozJblmHOixGCwcUGhUoUDtNe1pprYOWroCSpX"
                   "WHmGt/i""l9wp3aJq" "H""iPs"  "4ObzJqwaktnQStUUDhgTjNeeVV/roGotYeufV+MX0RyWj1selaBpXKgk1qNoVVxtGl+rnWNjlh2UjZUKBw1LR40MiA3OSY+OSU9KxsuIxQlJRQmKxgtLho1SEl2nabajp7Wb2CVpWeDsHyUu5KnuZCmtYuhtI2ft5Skt5OlsYqdr4SXr4WXroSVroGT" "q36QrX6Qw4iXkGJzOD1eGztjM0VrPUlrQFBxMzZPHgoPHA4TGxMXHREVIhoi"
                   "KzFGHhIWIBARIREUI""RA""WJBEWL" "BQZIA0RTi04d0tbORogQBoaMw8NaUFIiVVkfE1Th2ZoeklMgGVtd15mb0pPcDAxbi8xUi0vUzM2Xjk+WTM7ZzlAXzRBZzlKgUxgglt2lHKWmXadfV59WkBaYkhleFp8eVyEblaDV0RnSzlXqoe+hGqb"    "MidAGRAaFA0aOCpGbUpbnG"  "t1onKAoXKDhlZlZTpGTygwckFQjFdrnmh8jll2r3ynkGqZPihMRzBUUDdhVTtjmGq"
                    "Qp3WedlCGc06Hmmuc""""r3uanWm" "IhFOPnm2nnWyReVN4Ry5XNyFDOSE/PiZEPyZGPiZFOyNBSCxMTC9RPiRDNiA7GwYegXqirr74boG6U12VrImn2au7xZqwvZOqt4ujsIObqnmSqHaOrYKYtoygtIyfr4eYrIKUroOUw4qWk2t+PV""WC"      "O2CTVWiLU2WLTF6"    "GTkxxWEhqKR83JyAyHBMbHAsRJic5Iys8EAMBGQ4RHQ8SIBAUIhEWKRQbKhMdMRcidUp"
                    "ZT""i"  "cxOhMTNxE" ""  "Nb1"  "Jkh1xwdzpEfVJfelZkeExXe0FJf0BGeDEyfTM2cjQ5aDo9aUVEcFFPeklRdDxLdEJTjE9nlFJmik5hf""lZqdFhvf2KIlnOio3ytjmuUYERcPSYue1l426jiVz9XCAQJDQgTIRcUaUk8hVlfeExZYj"      "hDVy87ZjlEbEB""NZkFab0FYe0VbjVlxg1RaYT48UzpOSzJaWjpia0Z2fU6BhVCFhE+Go3GlvpC9vn6vo2CZm12do"
                    "2y""mqXWqpHShdlB5RSVRTCx"  "" "VRilOOyFDNx09PCBCSStPUTFXRyxOOiJCNx9ATSxZcVqTc2WdmHWisIKou4SksXqZmmeJmmSIn2aHm2KBmV59llx7nWiCo3OMqHySroeZtY+hxpCekmh8PlWCSW6fZXqdVWuRXHqkPFBuMCQ9c""GaMREB""i""KCM9HhQgFgsTISlBGRkkEAUEFQwPGQ4RHA8SHg8WIBEZJhMdHAoUZkBRWy89LgcIMgoIYzhGe1Beay02bjI8bDdCb"
                    "CkxfjM4fjM0UiYkUiYjUiUkTyQj"    "RiglSS0tTCcsTSUqSSYsRSMqSyUsSSMrPx8pVDlQlHObbE5sNCAvSzQ+WUBPXERVYUVbilh8x4GvYERdLSM1MSEjSDEfX0JLZkBSaD1HXjZEcExze1yUf2OokG2pjmScbT5odUVTjl5fe1Bng1iLk1+UnmaezYTCx3y7xYHAu4e/qWamsmeyuHu+p26rj1+RkGSQl2aUcEFyUSdbRh5ROBJBQyJMSitTTi1WTzBXRi1QQSpOUjNfZ0"
                    "R4bEiEXzh0ilGBwXuiomiUe""U18"   "dkd3jlmDp26UrnGWpmeLo2mJoWqInGGBlVp4kVl1m2WAsXaJilpwLUFxMlaJRExvQU1zV3ObR2CDJRknPB8sXFR4ZF+IJCI+DAYMFBEeFiI6EQsSEwsPEwwRGA4UGA4SHA8XIhAdIhAZFwgQYD5RVi46MQwOPRQWTh4cXi0" "vXzI1YzMzZDAwYS8vYDAvYzc5lFdZkVRXkldbk1lflFthlV5llGJok2Vqk2VqlGhtlm13mXN+mXB"
                    "5j19ogVVfY0paTDhKRzRGalFjcVZo"   "alNfcVNnnmyUbk9nZk5dUz1UZklrfFBkYztGbFB9d1mRjGyvqoXKyp7T1qrczafcwpfDvoi96rnx0ZzUmFSRrmijqmyn4a/f+ML0xofJs2y1zorM8Mru/+j27NDf27bPyZ3Cll6WXR1kZSlsg1WJpIGkdEh2WS5gWzViXT""Nkb0N7gVSQhVeXgViVhFqTglWNmmecg1iQaUZ/hVSFtX2k06HA0J+8yZi0wIuptHubqm6PpGiKoWi"
                    "IqW2KmmB+VCxKJjRhLFuTPV2NMEZzIzB""aJTNWHhgsXz5OVDlJRDxVdXCXLCQ6IhIZFRcpCRUsEQkOEgwQEAsPEAoQFwwWHRAaHhEcHg8YFggQKxUig1psuomcsYiex5+7zqS/zKC5y523ypezx5GrxIylxYqjv4SWvoWXwYmdv4qhu4GUu3uHvHuHvH6KvYGPvYKR""vYaYwYqcv4eawIaZxIubjWh7cldqSjVKSTZId11tfWFxhWl3cVlrdFdthmR3dFhpoG+QxoSsfVZ9kX"
                   "KqwJ""XL16LP3an""Sv4/Jq3nFtIDKw5jZ3Lfj5sLr3rrqw5XQrnG0nl2gu4y95rrqyo3P1ZfR8drxzr""jVp3qupGuplE+Wi0iRll+dvJjB79/y////1bHcf0GOeTqCgUKLn1anqWOxhlGcg1OWpGuoqW+rn2ulhlmYdE2Ko2mc2Yy12Zy/2aTDyY+yxYmsy5WyypeyvoqntH2cr3WUq3GOXzVXKCtYMGGaQFmFREVoPkdvOU5xHxgrKRQhWkJVaktcVkhkYll6KBspQio0MTJJ"
                  "ESE3DAMEEw0SEw0QE" "AkQEwoVHQ8bGA4XLhwnHw0aJAkZtpKv79P138rs28/y1srs18bp1cHm1sHn2ML""p1LvgzqbFxZawyJe2yJa1wJa5wJS6xI6xwoyuwY+wxpi6wIyssXWOtHSNt3aSunmTwnyVr3qalmyLelhvSTNGeVpypXyZlHCMblNsc1VuoHaWn3Was4GvnnSxq4O4zpvB1KDF0JzCyZbAsIC5sIDBs4LHt4fK16rZ47ji7sTu+tr/yJ7eoWCtmFWclFSar3G2uYLE"
                "qHy0nHKspH22t""YzD0K7c""7dn4//z//////ff""/sYPCdTGNi0iekkSoo0y6r2nBuXfEkl""WlsXW3xHzC""xYHBr3S0gVOXlWCb0Ii205a/wpO3tYapxJa7yJrBt4Srp2ySt3matn2dunqZoGuLUzRZQT1oREl1OytLLDFWQld9JSxSFQgoIRkvMyIuZ0hTSUBcLyY7KB0rLiAuMzBCJTtUCgYMEws""PFA4SFAwUEQsSFgwXEQYQQis6WTdJaTpS1bXS5tv12sfi2cXf2sXf2sX"
              "f2sbf28Tf3MPg3MDd2brRw6XJx"   "6jPyazQyq/""Sy7PWy7bazLjdzLrdzbrfzrncyq3PyqjJza3Kz7DN1LfVzLLWsIKrnWeIdlJrelV2n3KZXkBdbU9mg2KBfl+JY0luVUBgblNxj2yTq4W2xJvHy53HzZnF2KPK4KzU2qfY2KXY47Pk5rfo5bbs5b324br0z5nYvnq9olqjqGKtoGCwklKm3MLi/O3+/fz+//////////r/y6PUjD2cjkahz6zY7Nbw3Lvq27zv0rnox5fWv3XHx"
             "H3J"   "0IrQ1o/StHK6i1OdmmCfn2e"       "ie1GMjmecso27x6XTz7Dcx6fUv5jBuYesxI2ovoSfc0lucVJ4TDNWTSlGZUViW2mTOVZ5NDBlPDSFIyNsFxZaLipwJCBDHBMZMyg4LiM0JhckLkJfFyEyDgIEEgsSEgsTFg0WGA0ZBwAJPyg2pXCJbkdbw6a66s3g27vP27vO27vO3LvQ3r3R373S37vS4LnT4brUzaK+z6jH0a3K0rHL1LTO07bP07fQ1LfR1bjS17zW3MHe3MXf3"
            "cff"    "3sfi4c3o3sfhw6PIqnSfn2ySbkxrVD" "dPfVlyl3CJaExocFNvcFFqhGB4nXSPo3ait4WysHypuYKu0Z3E06DNzJnHwo/CypfMuoi7uoO9v4fBx4O3zIu3vpDDqni4yovFvHCxt2iws225t2+wuGOs4K7a++j5/+/76MLmu3S+zpbR9931//7//////O357MTm8s/u7sfu0pDVvnHE1I7T1o7Tu3""S8mluil2CiflOVZD+BlG2o1q/g0KrczaPZzKHXz6naxJ3PxZa6mm+Sb"
          "UpzlGmO"  "ZEdrPypJnWF3wHWJUzdQOzleZl2IRUF"  "wQD54NDV7Gxc1JxwjLSIyJR0rIhMbMjtSHy9FCQAAEQsREAkRFwsXHA8cFAsVGQsXonCLb0lfp4iZ/9v16bjS4q/J36vF4KvE4q3G46/G5K3F5q7G5azB35yr4aC15KO65qa75ai956u+567B57DD6bPE6bTF6rbG7LnH7LnJ7brN7L3O8cLS5sHTxKDCpHaggFZ4ckxlq36ZjmaBk2mFqXuVmG6IrH6bg1yBb0hqhVJrdT1RYz"
          "RLpXigyZb""ElWiQil+Qtoawsn+noGqakFyKkV""J9"  "lFeEk1+Upm6p1JrO4KfWyoK6v26xq1SkwW218LXi/Nj3+dfz78bq9tvy//3//+79/eP447LezYHG3Z7Y9sXw98vw4aPX0YXIzoPH0IfGwXu5uHq0qWylmV2Ub0eAc1CPuIrSwZDXw5LRvo7OoXO+l3GzlHGpa0t1Z0dqdVF0gl6BRjJSgVFpoWFzW05wSERlSkBfW1R4Yl1/Y1txSzdDGRIfMyY2QzJCNCUvKyo6IzpVCgULFw8"
         "VGREYGQ8aH""BAbIRUgSC9AonCNpW+PimF30aa57sDT6" "8HQ7sLQ/c3d/9Tl/9Lj/9Xl/9fn+s/d7K+48LS+8LS+8LW+8LXB77bC8bjD8rvF8rzG8L3G8bzG8LrF8LzH8L3J8L/K88HN+cnS8MjWkWiKilqBr3ybm2uHoXOQqnqZp3mXp3uXr4OfgV57ZUdlflt/imaSn3mqs4i5o3aZiV59nW+SvoyuyJa7vIet""qnafmWukroG93KXU15bKw4K75rTi4KrYwXGvuGis053I+dTv/+D7/+"
          "X+4LHZ5L/""g//T//OX42KXVq0ui2JfR//b//+r/9Mf" "s2ZDMyny/0ITF1ozHxYG6nGagf06GqmScsm6kgVCIhleXonK7qXvEq3/En3W8mnO4hmaweFiId1""VxYERmZklqVD1cWDtWQig8R0VrWEpoQTVRaWSPamWPTEBXW0FPIBkkKB4tOy0+QDA9OCc1MU5wFiAtEQUJFA4YEgsWEgsWCwUQIhUhd1Nqw4ussHmZGg0XJBkip3yT6rHNy5yvupKaxJmeuJCWrIeNrISL46e65anA46jA"
                "5K" "jD5KnF46zI5K7K5q/M57TN6brP7LvQ7b" "3R7cDQ78DQ77/P7r7N88DM7LnFvZm6lGuQpXKTrnuapnWVrX2bq36crYCftYaki2OCjWOCqXuWo" "3eXoneolWylmG2Prn2bvIqqu4epuoWpwoyywouzqnWfvYWu3KDN1ZvLz5XI1JvP4avbzZHEtoGwp3afrHWdypq6/+X758Xk0qHL/+r91qbTumWzs1+xz4/K8sTn3anTxoW9u260n12gqmynuXiykVeWhU2MhVCMwYzC3J"
                "vT0I/GvH+1j1ydlGu1qX/FpHu9l3OxkG2zhme""okWyPjmeJcVBzX0ViRjNLNCc+LSY/STVLPzVQc3CgUk9wEQ0aW0ZXOi87EQ0YLSIxPDA9Mh0nNURhJkFeAAAADQYSEAoVEAoVEQsXBwUMAAAAFAsXLiAvBwUJAAAAPyc2h1h0SCs7HQwSHw8WGgoSFgYOGwwRzYGNz4GQz4GQz4GP0IGP0oKS04SU1YaW2Imc2oyf3I6j35Sq4Zyx46O346K44aCy46Gu05ai4MbkyqnLcDpfnmu"
              "RtYCisn+es4ChtIKgtIKhoHGSpneXw46vwIqnv""omnl2iTrnuf1Zq71ZnA0pa9yo+zzZK4zpG4x4uy0JW805W92JvH0pTG1JrJ3qrUy6HGqHuezZm+5K3Ru""nyh5rfT/976xoS9zZXHxIbCw37Bvnq9rmeqoleZo1ibsG2uu365klaVkVKVnGGin2aksnWzs3q22bXe4rvl2q7cxJjRtIbIp3vFpHnFpnzDlXCwgV+YcVOEZ0xxhGF/hWKAgF58Vj5XTTpPPi5ARzJFNi9HVlR4NS5C"
            "FA8cX0haSDpHCQkUHBUkPjA+SzdDNi9AJkJgBwoQ""CAQKCwYSDQgTDwgUEAkWCgURAAAEAAACFxAaLB8pHhMaEQoOHBIYJxkmIxgkIhgiIBcfKRkfxnVyynl3y3l4zHl8z3uB0X6E1IGH1oOI1n+G1nyF13+L2YGR2Yub3Zao35ut3pus36Sx57W+2LLI28TqqHagik13sHaevYKnvICktn2fvYanxo+to3KR""oG+P0pi74aPFyo2vv4Wr3Z7D3ZzE3JvF2pnD2ZjB2JfA0pG65qjQ663"
          "Uzo63yoq22""KHJ2rTU7rHSyoyv4JjG/7rs9qPU95z""O/6zc1o7FwHa2yYDAuHCxmFWVf0OAtXOu5a7e16fWrXq0qHOw0KTU16/a37nh4L7j377j27rf17fc1bLb1LHc2bbgxZ7RoHe+l267oXrDk3O4g2WcZ0tvbk9phmR9hWJ8bU9pRzZLTjpOPCw+GRUlJR4sHBUhFBEcRzVEMSY2CwkVDAkVJx4tPS9AMSY1IzZQDBQdDQcJDAkQCAYODQkSBQMKCwYOJBkkNCMxOik2OSk1LiEvJxwo"
         "KRwnKhwnJ" "h""kjIBUcHxUZKBcbzIV/0IqH0ouK1I""2Q1ZCV2JOW2pSa25ac25ed3Jqg3qGn36Wr36iw4am2462557S86rzA7sDE5rG13rbF5MfpwpTBrm+ft3aiwIGpv4Opx4quyY6utoGgZkJaUjRJfFRwonWUrXyXuYGfwYSqxoiwzYy10ZG5xIStwYOqtHqgklh/qWqU1qXK1q3N7qTJ/6rQ5KjL8ZvM8KL""R7prM/5fM543E0IbB0X68s2eiiFCDf099jFmHq3mrt4G2xYq/x5TG1"
        "K7Z5sXq4b3k4L""rh37vf17Lb0qvY1a7Z0arY06rY06f""T""2q7UzKHLlHGuhGWrknGzl3rFel6TYUZbflx1j2mEbVFnRDFFPC5BJB4tIx0rMyk4HBYiCAcNLyUzKB8rFA8UDAkPFhAZLCEtLiMxKUVkDhkoFgsOFA8WCAYIAwMFEg0SPSw3RzNAPCo5NCQxNCQxNiYzLR4lIhUXIBQXIxgiLCIxLiQ0MCMvxX9wyY""R5zIR8z4Z90ImC042F1Y6L2JGR25SV2peY2ZmX3Juc3p2h4J6k4Z6m"
       "4p+m4Zyi35eb5Jug4ZGV3Z2l4r/S1K7SxJPAwIO0wX+uwoGr""wIGozo6zv4WmZkBaOh81dVJSj2poXj1VUi5JWTBKYTdSYzhWXDFPXzFSZDNZilaCzZzE4qbI8JG3/5G7+pS995C+77Xb3qvM+pTA6Z/HyIW9yHm1tGuflFuIkV2IiFqDcEt6nWicw5LIvaPY2bfo4bPl2aja06XV0KLVyZzSzaHR0KPRz6HPyJzLxp""nHy5zHx5nDzqDGw5rAjG6mh2ivi2ysXkVob1FnX0ZcblJqVD9TQS9C"
       "SjNCIh4sLCU1Nik7LCIyEAwWJh4tNCg4IRkiFA0VBQMMDAgOG""hEXICk9DhMeFg0TGBAaCAULBgUGOyo1TjZGQi86Oys3PCo4QCs3JhgcKh8sQjVSUERrXk9+aliNa1mQaVWGtWFNuGRSumRUvGNVvmVZwWZdw2phx25myW5oynBrzHJszXJsz3Vx0nl203h21HV31nR513R62Xh+3HyE4H6G232D3ZGc26Cz0Zm8yZC""/yI3CyYrAx4O204u725XCvoCos3iNomyEg1R5eERofEVpd0VoeUdt"
      "hVF6nWCPx3+v5JK954qu8Hae9HCd8HGe9nGe7H6n3cPd9KLF75m""9y5jAwXivrGqboWOOmmOOiFh/lmqVg2GcajpmgWiTRVWAd3Cel22ds4O41aHWvY3Hs4a/xZfHzJ7JypzHyZvEw5bBwJS/vpO9u5G5x5vAroe0nHe4n3WiUjVQfFx2VD5UPytDRC5IXDxTeU1gXT5QJB0tLCM2PjBDKiEvDQgRKB8vNCs8KCAsGxQe""GxUjMSYzEggNAQAEFQ8ZIBYhBgMLHhQeTDdEQy87RDA7RjI9PSs4H"
       "BEVLSc/YVWNc"    "mGgc2KecGCXbFyRbFqRcFqMtmRPu""G""""dTuGdVvGlav2xevmlev2lewGpdvWZZul1RuldPu1VPuVVOulVPu1RQvVNTvVFVvU9Vv1BXw1VbyFZeyldj0Flj011j02t00nSC0HeS0H2m0Ia2zIe6zoa925HK1o3KyoC4wXKiyI" "Ox3p3NyH6uxXGc23uf5n2c6nmV7nGL8XGO7nmZ7X+f7ou" "q85W07bvR48/n5rPQ2rfSw4OwrmmZpWaRoWaOglZ9aURnnHGos4S"
        "6cE2BTjh"         "sUDldbk1udlNyeleBtIa+nnaruI25""ypzHwZbAx5jAw5a8vZO6vpW8uI+1vZG8wpe7qYS2kG2nhF2BZENkXEJhUjdVTjFTnnCdzY/BdU92UzROcExrRjJMLyc5OCxAHxcmGRMfLSMyKyIyGxIeEAkYKR80LSlABgQXCQEOKh"  "0qEQkUKBspUz1NRTJBSDRCPyw7GA4SKiI5cWWjbV6YZl" "aLZliMZ1iNaFiOaViNbFaGtW1er2NVrV9Qr15Ss2JWtGVauW1hvn"
                           "RptmVcsVVNrEpFrUdEqUNBpj47pT06""p0I/rktJvF9dwmdnwGNkxmdnzG5u0HR013x+3ICC3n5/331723h22XR61nWB0mx/0mR71WR72GR6119z3HCC4nuN3Wx94Wh06Wt06m536HJ953yJ6omZ7Zqp8Ky68b3H7rTB79Li4"   "8bgzJGr0aLDr2qXqmyVr2+Sk16Dilt8f1V6d1KGeVN5f""luKimCAhlpxh155hWB3dlVzc1SDdld+sYix0J7H1J7Gt5G6uZO7w"
                          "5TAroWwvpS+iWmTknGelXexX0yNXUmE""W0JhVzpVVjpYoXqk3KnavIi6d1F6RSlKeE54YEFmKxg6QTJSVUNlOy1PJxs6Kx06OS9MKBw0LR83i1Fki1tzNi1PGQomIA4hUTdLXD9UVTtPRzFEKRonKBssZFSPcF+hZlWNaFeNa""" "FmOaFiNZ1eNaViObFaJlDgnmzwrn0Ixn0Eynz4vnz0to" "EEyo0M3pEA2q0o+s1dJuF5Ru2NWxXVownJqvmphxHVp0IV50oh8"
                         "1pCD2JSJ1I2E1o2D1ouD1IN+04F+1H96z""mxlyVtWzFxX0mNd0mBbzVZSz1RQ0lZU1FNT1lNT2l5d2mJj3mdp325w5H+A5oaJ5oeM5IOM5IKN44SQ3XV747K828fis4Kgy5e7qWaQrm+Trm6LjVp8nWmFiVt5fFZwfFhveVVrh" "Ftyhlx2hVt0hF11dFNtaEtliWSGoHmua0VueFFxXWeQRVW" "AbGiTbE52g2WUTjpTXUl0Zk97TzxhUD1hWD9SW0BVVDhVelh7Zk"
                        "doUDNSVjRXbElzc1F4eE5skWB4tHyMx4GKqmlyfk5lfFd1v4ydv3l+y3+C5IF754eDwoSUeVRvZk93aUNpWjVPWzpTSC9FJBMfSjhfeGSvYVCRZVaTZVaQZVaNZliMaFiNaFiOa1iInUYvq1ZArFtFr11Hs2JLuGhQvGhQvWlUw""3VcuWpRsl9MsFtHrVZEsFpMslxPsFdJr1JGqktAqEU7qko/qU" "pApUI7pUA7pT04pTk1pjg0qDg2qTs7rUA+sURBt01LvFNQuk1L"
                       "vk9RxlVYyVpZzWBd0GJg2Gtn3HFy5YqL5YaA""5IR/5IF833Z04Hd34Hh74nlz05yg5dnzuo6vt3qisXCZt3mcrW6Om2OBnWmDjF52g1lxelRsglpxgFlwfllvf1hvf1pxdVVqZUhXgG"     "GFwJPKh2aaTj1mMS9cGSVPPDhQQzJPTjtZWUJXPy5FPCo7UDlEXUJRX0RXVTxTYUJeXTtaVjJUZT" "9mckt5jlt9o2Bst2Vi1nZl2mpQ2GhO3XJa13Bczm1cz2ZS1WpX"
                      "0WhVyWVVzWRU2WZT4npwt3aHckZoa0RkaER""gSy9I""MBswZ06Hhmezc1acb1SaalaXZ1eSaViSaleSa1eRa1WKkDwlmkYuok82qVpAsWhMtmxTr1xHplE9"    "oEo1l"  "j0pkDIjjzA" ""      "gji0hjCofji0hkzMnlDUqkTMqkjIpkC4lkS4lkzAoky4plS4snDYzoj06pkQ+q0lCrkt" "EsU1GtE1GuFFIv1xUw2NgzGliz2hc0Gtb13Fh2Ghc4n9+5ouI3"
                    "Gxg22pf2mtg2m1j3HBm2m1n4GtjwGlp6+f00q/Ho16Hv""Hylu3yht3WWrG6Km2WAlmR9l2Z+mGiBiV53e1Rqe1VofFdqeVVofllnaExueF+dkXClmnmqj26""ga014XUBYVjxQV0JXZUtfTDd"                "ORDBAY0dXZUlcZUdcZURecUlob0Job0x7fmCVjGqalWqQnmR3sHB9tniFr212s"  "GNnuFdPv089wlA7v045t0o2tEo3s0g4tEg5tUc6t0k7u0c30U"
                   "0zjEpRNzhjVjVRWzVPPR46b0qMxKbhxqnVe1Seg""Fupel""ykdFmfclmacVmXb1WQhSwXijMdjzojjzsiijQehiwYgicUgCcVgCgWhCwbhS4dhjAfiDEgiDIhijMjizIjizEiiy8hii4fiy0dkjAi"                "ljUpmj0xp0w7r1ZBslpCtmBDumFDvGJGv2RIvl9GvF1GwmFIx2VIxWBExl5D" "yl5FzV5I2XZn4n1u0FhEz1hH0FxK0FlJ0FlJ0VpL0VtP1FxUy"
                  "E1B1rG08vL/rm+Ut3WeuHectHKRrG6Ln2eEqnCMqnGLr3iQp""nOLlGV9j2N3iWF1f1lsbkxdYkdsdFV/X0ViRTJKUDlPakxca05faExfdVZpZkxgVDtPcl""JldFFnb0tjd0xreERrf1WFjW+jom"                  "+Rr2Jq" "sVRMulNCvFI9uEw3uE47tFJDqU1Fo0M7qDwrrDwprUAsrUAupzo"  "opzspqDsrqjsrqTorrTwvuj0spT04f1NvT0FqWj1nQBEyTCV"
                "a5M32/""/3/t5vKgV2lh2GvgV2rfFuld1ugdlmWhC0X""hCoWgi""oUgCgTgCcUgSoWgiwXhCsYhCsYhC0ahC0bgy0bgi4chDAcgzAchDAdhzAciTAdjTYmlE""Aym0tAolZMqVdCr1s4sF02r1wy"""                  "rlg"    "xrFQvsFUxr1MwrU4vq00wr04yslAyskwwt00xuk0xxlw72IRbyG"  "FBvks0v045wE05xE47x1A8yVI+y1VDy1dJ0VVFt0xF49fi6d"
               "Tsp2C" "MuXWguXebrm2NoWWEpmqGnWV/lWN6lGZ7m2q""Bnm2Cl" "Wl+gFptgFlviWByeFRgZ0lXbk1fgVxtf1pse1hrfFtudFRocE5kgFlzgll1e1BvgU" "xzhFKAnIC0onmhsl1bsjsh" ""                     "sTIQr"   "TQUozAWoTIbnTIbnDMdmjAbmy0VnDEWmTMbmDEdnDYfojomoDckn"  "TQgmjEenDQgoTUjpzcmpzcotzYhwzklp0lPg1NueVyCUj1x"
             "xbja//" "///+v/rJPFe1uliWWwhmGtf16nfFqbgC4XhCwX""hCsXhS" "sXhCwYgC0YgC0YgS0ZgC0Zfy0YgS4agC0beysYfCkWfikWgS4dhzsujk1DllpS"  "nF1UnltNnVVBnU" "4un"                           "kspnksq" "oEoroEsroUssoUgqokgqo0cqpEgqpkgtqUQss0swr0ctrkIovlIx"  "uEoqr0Amskcvs0UxtUUyuEUzu0U0vkg1wEg2wUo3wk0/wT8"
            "vskpB" "4tHl3cXpqWSSp2OQtHOXsXCOrXGMpmyGnmh/l2Z7""kGN4i"   "l90hVtwgllvl2p+mGuAhl50i2N4iWB2gVpwgFpvf1lvf1hwhlt2lGSEkF+Di"  "FV7h058lW+lv""a3"""                              "Yvo2cqzs" "qqyMFqzQdozginDEbnjQfmzQfki4XkC4YjywZkC0ZjSwYjCwXjS"   "wYjysZkCsYljAamTMemDMeky4blC8cmTEenTAfojIhqTIh"
          "tS8ZqC" "0hrVBQj0BGjnKV//3///T/7tf2inKxgGCqiWSvhmGsgFygey"   "sUgS8WgC0WfywWfisWfCsXfCwYeisXeSsYeSkWeicUeSgWdykXey0egTYoi" "EE0""jEo8jk08j"  "U"                               "g0jUQqjUEjjz8fjkAhj0AjkD0jjjwijjwikDwjjzshkDwikTwhkzwhlTshnz8oo"   "UEnnDshojwinzohoDgioTwmoT4npT4ppj8qqD4qqz0qrT"
"4ssD4tsj4utD4xuEI3si4gpzk10KW317/jtYW1oF+KpGKHq2uLqm+Ko2mDn2iClWV8i192h1xyiF50hV5xhV1xkmR7o3KLkGZ+gFlyhFt2il56lmaEmWaJjlyChlF4i1iOnny2t5KxsWBfoCIJpisRojMfnTEcmTAamC8ZlzEajy8ZiCoWhigXgycVgCYWfyUXfiQXfSMWgCQXgiYZgCMVhCcVjCwakC4bkS8bjiwaki4bli8cmTEfoTMht0IltjshrCkSgSAcrZa9//////v/tZ/Pc1ehi2exiWOuhF6jci"
"YTeCgUdicUdScUdScUdCYUciYUdCYUdCYTdSYVdykaeC0cfDUhgTsogTsngjkigjccfjEVfC8TfTAUfDAXfTAYgDEafC4aeiwYeCkXeCcXdyYXeScXeScXeSgXeCcWgioZgywafCgVgikYgSsYgSsZgiwagi0bgy4bhC4chi4chy4diS4eii4ejC8gkTEilzQkmTQlnTQpniUYlBsRrV5gwI6eqnWam16Gl1p9k1t6mF98jVt0hVhwiVxxiVxzi150j2F3jWB2h1xyiV51jGB5il94jmF8kGCAhlh6flB0fU"
"9zg1N9jFx+mVdbiCUWfA8BgiMVfSMWeyITeiIUeCETeCMUeSMSdB4Rcx4TcRwRbhsQbhsRcB0RcR8Rch8VcR8WciAVcyEWdCEXdSAVeyUWgSgXgicXhCkYhywYji4amDEbqUEgtEkrtEE5qSwjfx4XqIWi9ubz59HvjHGtgF6liGWwg1yeAAA=";

#include <stdio.h>
#include <io.h>
#include <windows.h>
#include <time.h>

#define error(message) { printf(message "\n"); fflush(stdout); system("pause"); exit(-1); }

#ifndef MIN
#define MIN(a,b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x4
#endif

#define MID_FILE_PATH "music.mid"
#define LYRIC_FILE_PATH "lyric.lrc"
#define PIC1_PATH "pic1.bmp"
#define PIC2_PATH "pic2.bmp"

#define FRAME_WIDTH 120
#define FRAME_HEIGHT 30
#define DELAY 1000  // 歌词播放延迟，用于让歌词与声音对齐
#define CHARACTER "#"   // 在控制台用来显示图片的字符



#pragma pack(1)
typedef struct {
    unsigned char B, G, R;
} Pixel, ColorBGR;


typedef struct {
    int width, height;
    Pixel* pixels;
} BitmapImage;


typedef struct {
    int time;
    char lyric[100];
    char translation[100];
} LyricLine;



char strBuffer[(FRAME_WIDTH + 1) * (FRAME_HEIGHT + 1) * 24]; // 字符缓冲

HANDLE hConsole; // 控制台句柄

BitmapImage pic1, pic2; // 两张图片

LyricLine* lyrics; // 歌词数据
int lyricLineNums; // 歌词的行数




// Base64编码和解码表
const char* encode_table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
const char* decode_table = "                                           \x3e   \x3f\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d       \x0\x1\x2\x3\x4\x5\x6\x7\x8\x9\xa\xb\xc\xd\xe\xf\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19      \x1a\x1b\x1c\x1d\x1e\x1f\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f\x30\x31\x32\x33     ";

// base64字符串解码
BYTE* base64_decode(const char* source_str, int source_str_length, int* decoded_data_size) {
    
    // 计算解码后数据的大小
    *decoded_data_size = source_str_length * 3 / 4;

    // 申请内存空间
    BYTE* decoded_data = (BYTE*)malloc(sizeof(BYTE) * (*decoded_data_size + 1));
    BYTE* decoded_ptr = decoded_data;

    // 首先，4个字符一组，进行解码
    int n = (source_str_length + 3) / 4 - 1;
    for (int i = 0; i < n; ++i) {
        char d1 = decode_table[source_str[0]], d2 = decode_table[source_str[1]],
             d3 = decode_table[source_str[2]], d4 = decode_table[source_str[3]];
        decoded_ptr[0] = (d1 << 2) | (d2 >> 4);
        decoded_ptr[1] = (d2 << 4) | (d3 >> 2);
        decoded_ptr[2] = (d3 << 6) | d4;
        decoded_ptr += 3;
        source_str += 4;
    }

    // 对剩下的字符进行解码
    n = source_str_length - 4 * n - 1;
    while (n > 0) {
        if (source_str[1] == encode_table[64]) break;
        *decoded_ptr = decode_table[source_str[0]] << (8 - n * 2) | decode_table[source_str[1]] >> (n * 2 - 2);
        decoded_ptr++;
        source_str++;
        n--;
    }

    *decoded_data_size -= n;

    *decoded_ptr = '\0';
    return decoded_data;
}




// 解码出4个文件的数据，并且写入文件
void decodeDatas() {
    const char* files[] = { MID_FILE_PATH, LYRIC_FILE_PATH, PIC1_PATH, PIC2_PATH };
    int lengths[] = { 14016, 3244, 5484, 14476 };

    const char* base64_ptr = s;

    for (int i = 0; i < 4; base64_ptr += lengths[i], i++) {
        // 判断文件存在，就跳过这个文件
        if (_access(files[i], 0) == 0)
            continue;

        FILE* fp;
        fopen_s(&fp, files[i], "wb");

        if (fp) {
            int dataSize;
            BYTE* data = base64_decode(base64_ptr, lengths[i], &dataSize);
            
            fwrite(data, sizeof(BYTE), dataSize, fp);
            
            free(data);
            fclose(fp);
        }
        else error("写入文件时出错！");
    }
}



// 开启Windows的虚拟终端序列支持
BOOLEAN enableVTMode() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE)
        return FALSE;

    DWORD dwMode = 0;
    if (!GetConsoleMode(hOut, &dwMode))
        return FALSE;

    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    if (!SetConsoleMode(hOut, dwMode))
        return FALSE;

    return TRUE;
}




// 设置控制台的光标到 (x, y)
void setCursorPos(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(hConsole, coord);
}




// 读取Bitmap图片
BOOLEAN readBitmap(const char* filePath, BitmapImage* image) {
    FILE* fp = fopen(filePath, "rb");
    if (!fp)
        return FALSE;

    // 读取Bitmap的文件头部分
    BITMAPFILEHEADER fileHeader;
    BITMAPINFOHEADER infoHeader;
    fread(&fileHeader, sizeof(BITMAPFILEHEADER), 1, fp);
    fread(&infoHeader, sizeof(BITMAPINFOHEADER), 1, fp);
    int width = infoHeader.biWidth;
    int height = infoHeader.biHeight;

    // 读取Bitmap图片的数据
    Pixel* pixels = (Pixel*)malloc(sizeof(Pixel) * width * height);
    fread(pixels, sizeof(Pixel), width * height, fp);
    fclose(fp);

    // Bitmap图片的行顺序是上下颠倒的，这里把它颠倒回来
    Pixel* temp = (Pixel*)malloc(sizeof(Pixel) * width * height);
    for (int y = 0; y < height; y++)
        memcpy(temp + y * width, pixels + (height - y - 1) * width, width * sizeof(Pixel));
    free(pixels);
    pixels = temp;

    image->width = width;
    image->height = height;
    image->pixels = pixels;

    return TRUE;
}



// 在(posX, posY)处打印图片
void displayImage(BitmapImage image, int posX, int posY) {
    int bufferIndex = 0;
    int x, y;
    int displayWidth = MIN(FRAME_WIDTH - posX, image.width);
    int displayHeight = MIN(FRAME_HEIGHT - posY, image.height);

    bufferIndex += sprintf_s(strBuffer + bufferIndex, sizeof(strBuffer), "\033[0m");

    for (y = 0; y < displayHeight; y++) {

        // 打印posX个空格，用来占位
        for (x = 0; x < posX; x++)
            strBuffer[bufferIndex++] = ' ';

        for (x = 0; x < displayWidth; x++) {
            Pixel pixel = image.pixels[x + y * image.width];

            // 在像素值为纯黑的地方打印空格(相当于透明)
            if (pixel.B == 0 && pixel.G == 0 && pixel.R == 0)
                strBuffer[bufferIndex++] = ' ';
            else
                bufferIndex += sprintf_s(strBuffer + bufferIndex, sizeof(strBuffer) - bufferIndex, "\033[38;2;%d;%d;%dm" CHARACTER, pixel.R, pixel.G, pixel.B);
        }

        strBuffer[bufferIndex++] = '\n';
    }

    strBuffer[bufferIndex] = '\0';
    
    setCursorPos(0, posY);
    printf(strBuffer);
    fflush(stdout);
}




// 调用Windows的API播放mid音频 (ps: 这个API用来播放mp3音乐也是可以的~)
BOOLEAN playMusic(const char* filePath) {
    HMODULE module = LoadLibraryA("winmm.dll");

    typedef MCIERROR(WINAPI* MciSendStringT)(LPCSTR lpstrCommand, LPSTR lpstrReturnString, UINT uReturnLength, HWND hwndCallback);

    MciSendStringT func_mciSendStringA = (MciSendStringT)GetProcAddress(module, "mciSendStringA");
    if (func_mciSendStringA == NULL)
        return FALSE;

    char buff[255], command[100];
    sprintf_s(command, 100, "open %s alias playsound_134", filePath);
    func_mciSendStringA(command, buff, 254, NULL);
    sprintf_s(command, 100, "set playsound_134 time format milliseconds");
    func_mciSendStringA(command, buff, 254, NULL);
    sprintf_s(command, 100, "status playsound_134 length");
    func_mciSendStringA(command, buff, 254, NULL);
    sprintf_s(command, 100, "play playsound_134 from 0 to %s", buff);
    func_mciSendStringA(command, buff, 254, NULL);
    return TRUE;
}




// 读取歌词文件数据
BOOLEAN readLyricFile(const char* filePath, LyricLine** lyrics, int* lineNums) {
    FILE* fp;
    fopen_s(&fp, filePath, "r");

    if (!fp)
        return FALSE;

    char line[200], lyric[100], translation[100];
    int minutes, seconds, milliseconds;
    int size = 10, i = 0;

    LyricLine* _lyrics = (LyricLine*)malloc(sizeof(LyricLine) * size);

    while (fgets(line, 200, fp)) {
        if (sscanf_s(line, "[%02d:%02d.%03d]%[^(] (%[^)])", &minutes, &seconds, &milliseconds, lyric, 100, translation, 100) == 5) {
            if (i == size) {
                size += 10;
                _lyrics = (LyricLine*)realloc(_lyrics, sizeof(LyricLine) * size);
            }

            _lyrics[i].time = minutes * 60000 + seconds * 1000 + milliseconds;
            strcpy_s(_lyrics[i].lyric, 100, lyric);
            strcpy_s(_lyrics[i].translation, 100, translation);
            i += 1;
        }
    }

    *lyrics = _lyrics;
    *lineNums = i;

    fclose(fp);
    return TRUE;
}




// 彩蛋
void surprise() {
    // 生成一个随机打乱的排序列表
    int len = pic2.width * pic2.height;
    int* order = (int*)malloc(sizeof(int) * len);

    srand(time(NULL));
    int i, j, tmp;

    for (i = 0; i < len; ++i)
        order[i] = i;

    for (i = len - 1; i > 0; --i) {
        j = rand() % (i + 1);
        tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }

    // 按照随机的像素点顺序显示彩蛋
    for (i = 0; i < len; i++) {
        int pos = order[i];

        Pixel pixel = pic2.pixels[pos];

        setCursorPos(pos % pic2.width, pos / pic2.width);
        printf("\033[38;2;%d;%d;%dm" CHARACTER, pixel.R, pixel.G, pixel.B);
        fflush(stdout);

        if (i % FRAME_WIDTH == 0)
            Sleep(50);
    }

}



// 播放歌词
void playLyrics(LyricLine* lyrics, int lineNums) {
    clock_t startTime = clock() + DELAY;

    for (int i = 0; i < lineNums; ++i) {
        
        // 等待到第i行歌词的播放时间
        while (clock() < lyrics[i].time + startTime) {
            Sleep(100);
        }

        // j表示打印歌词的开始行数，end表示打印歌词的结束行数，默认为打印 第i-4行 到 第i+3行 的7行歌词 
        int j = i - 4, end = i + 3;

        // 第i行歌词的高亮颜色，默认为知更鸟色
        ColorBGR color;
        color.B = 243;
        color.G = 156;
        color.R = 131;

        if (i < 8) {
            j = 0;
            end = i;
        }

        else if (i < 11) {
            j = i + i - 14;
            end = i + i - 7;
        }

        else if (i < 22) {
            j = i - 4;
            end = MIN(end, lineNums - 1);
        }

        // 彩蛋
        else if (i == 22) {
            surprise();
            continue;
        }

        else if (i > 22) {
            j = i;
            end = i;
            color.B = 155;
            color.G = 213;
            color.R = 178;
        }


        // 将要打印的所有歌词写入缓冲区，然后用puts一次全部打印出来
        int bufferIndex = 0;
        for (; j <= end; j++) {
            if (j == i)
                bufferIndex += sprintf_s(strBuffer + bufferIndex, sizeof(strBuffer) - bufferIndex, "\033[1m\033[38;2;%d;%d;%dm%-50s\n%-50s\n\n\033[0m", color.R, color.G, color.B, lyrics[j].lyric, lyrics[j].translation);
            else
                bufferIndex += sprintf_s(strBuffer + bufferIndex, sizeof(strBuffer) - bufferIndex, "%-50s\n%-50s\n\n", lyrics[j].lyric, lyrics[j].translation);
        }

        strBuffer[bufferIndex] = '\0';

        setCursorPos(0, 0);
        puts(strBuffer);
        fflush(stdout);
    }
}




int main() {

    // 设置控制台编码方式为utf-8
    system("chcp 65001");
    SetConsoleOutputCP(CP_UTF8);


    // 设置控制台字体为黑体，防止出现乱码
    CONSOLE_FONT_INFOEX cfi;
    cfi.cbSize = sizeof(cfi);
    cfi.dwFontSize.X = 8;
    cfi.dwFontSize.Y = 16;
    wcscpy_s(cfi.FaceName, 32, L"SimHei");

    SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, &cfi);


    // 获取控制台的HANDLE
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hConsole == INVALID_HANDLE_VALUE)
        error("获取控制台句柄失败！");


    // 启用Windows虚拟终端序列支持
    if (!enableVTMode())
        error("无法开启终端虚拟序列支持！");


    system("mode con cols=121 lines=31"); // 设置控制台大小
    printf("\033[0m\n"); // 清除文字样式
    printf("\033[?25l\n"); // 隐藏光标


    // 解码数据
    decodeDatas();

    // 设置控制台缓冲区大小
    setvbuf(stdout, NULL, _IOFBF, (FRAME_WIDTH + 1) * (FRAME_HEIGHT + 1) * 24);

    system("cls");

    // 读取 图片数据 以及 歌词数据
    readBitmap(PIC1_PATH, &pic1);
    readBitmap(PIC2_PATH, &pic2);
    readLyricFile(LYRIC_FILE_PATH, &lyrics, &lyricLineNums);

    // 在右下角显示第一张图片(pic1.bmp)
    displayImage(pic1, FRAME_WIDTH - pic1.width, FRAME_HEIGHT - pic1.height);

    // 播放音乐
    playMusic(MID_FILE_PATH);

    // 滚动歌词
    playLyrics(lyrics, lyricLineNums);

    // 释放内存
    free(lyrics);
    free(pic1.pixels);
    free(pic2.pixels);

    system("pause");
    
    printf("\033[0m\n"); // 清除文字样式
    return 0;
}